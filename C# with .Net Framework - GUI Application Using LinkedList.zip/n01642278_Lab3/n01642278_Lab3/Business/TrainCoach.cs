﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace n01642278_Lab3.Business
{
    internal class TrainCoach : IEquatable<TrainCoach>
    {
        public int CoachID { get; set; }

        public double LoadCapacity { get; set; }
        
        public string CoachType { get; set; }

        bool IEquatable<TrainCoach>.Equals(TrainCoach other)
        {
            return this.CoachID == other.CoachID;
        }
    }
}
