﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace n01642278_Lab1.Entity
{
    internal class Customer : IEquatable<Customer> // propfull tab twice
    {
		private string firstName;

		public string FirstName
		{
			get { return firstName; }
			set { firstName = value; }
		}


		private string lastName;

		public string LastName
		{
			get { return lastName; }
			set { lastName = value; }
		}

        public override bool Equals(object other)
        {
            if (other == null) return false;

            Customer otherCustomer = other as Customer;
            return Equals(otherCustomer);
        }

        public bool Equals(Customer otherCustomer)
		{
			if (otherCustomer == null) return false;

			return ((firstName == otherCustomer.firstName) && (lastName == otherCustomer.lastName));
		}
    }
}
	