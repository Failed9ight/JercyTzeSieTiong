package productsys;
import java.io.Serializable;
/*****************************************************************************************************
 * ITC 5201 - 0GB                                                                                    *
 * Assignment 2																						 *
 * Roger Paredes																					 *
 * Jercy Tza Sie Tiong																				 *
 * Ryan Phil Ancheta																				 *
 *																									 *
 ****************************************************************************************************/

/* The Product class must implement the Serializable interface which allows objects of the class to be serialized and deserialized,
 * it allows them to be read from and written into a binary file */
public class Product implements Serializable {
	//declaring variables 
	String productName;
	int productID;
	String productDesc;
	int quantity;
    double unitPrice;
	
	//Constructor for Product Object
	public Product(String productName, int productID, String productDesc, int quantity, double unitPrice ) {
		this.productName = productName;
		this.productID = productID;
		this.productDesc = productDesc;
		this.quantity = quantity;
        this.unitPrice = unitPrice;
	}
	
	
	//Getters and Setters for attributes:
	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductID() {
		return productID;
	}

	public void setProductID(int productID) {
		this.productID = productID;
	}

	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}
	
	
}
