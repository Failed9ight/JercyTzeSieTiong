﻿using n01642278_Assignment3.Items;
using System;
using System.Collections.Generic;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace n01642278_Assignment3.Database
{
    internal class ItemDB
    {
        private Dictionary<string, Item> inventory;
        HashSet<InvoiceItem> finalInvoice = new HashSet<InvoiceItem>();

        
        // Methods for Inventory
        internal void InitializeInventory()
        {
            //Restrict access of modifying initialization of the database
            PrivateInitializing();
        }

        private void PrivateInitializing()
        {
            inventory = new Dictionary<string, Item>
            {
                { "1", new Item { ItemCode = "1", Name = "First", Price = 10,
                    QuantityInStock = 100 }},
                { "2", new Item { ItemCode = "2", Name = "Second", Price = 20,
                    QuantityInStock = 200 }},
                { "3", new Item { ItemCode = "3", Name = "Third", Price = 30,
                    QuantityInStock = 300 }},
                { "4", new Item { ItemCode = "4", Name = "Fourth", Price = 40,
                    QuantityInStock = 400 }},
                { "5", new Item { ItemCode = "5", Name = "Fifth", Price = 50,
                    QuantityInStock = 500 }}

            };
        }

        internal Item[] GetItemsList()
        {
            return inventory.Values.ToArray<Item>();
        }

        internal bool AddItem(Item addItem)
        {
            try
            {
                inventory.Add(addItem.ItemCode, addItem);
                return true;
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show("Error! " + ex.Message);
                return false;
            }
        }

        internal Item FindItem(string itemCode)
        {
            if (inventory.ContainsKey(itemCode))
            {
                return inventory[itemCode];
            }
            else
            {
                return null;
            }
        }

        internal Item Update(string targetItemCode, double targetItemPrice, int targetItemQuantity)
        {
            if (!inventory.ContainsKey(targetItemCode))
            {
                return null;
            }
            else
            {
                inventory[targetItemCode] = new Item {ItemCode = targetItemCode,
                    Name = inventory[targetItemCode].Name, Price = targetItemPrice,
                    QuantityInStock = targetItemQuantity};
                return inventory[targetItemCode];
            }
        }


        // Methods for Invoice
        internal bool AddInvoiceItem(string name, int quantitySold)
        {

            foreach(Item item in inventory.Values)
            {
                if (item.Name == name)
                {
                    InvoiceItem invoiceItem = new InvoiceItem
                    {
                        ItemCode = item.ItemCode,
                        Name = name,
                        Price = item.Price,
                        QuantitySold = quantitySold,
                        SubTotal = getSubTotal((item.Price), quantitySold)
                    };
;
                    if (!finalInvoice.Contains(invoiceItem))
                    {
                        if (quantitySold <= item.QuantityInStock)
                        {
                            finalInvoice.Add(invoiceItem);

                            string updateItemCode = item.ItemCode;
                            double updateItemPrice = item.Price;
                            int updateQuantityInStock = item.QuantityInStock - quantitySold;
                            Update(updateItemCode, updateItemPrice, updateQuantityInStock);

                            return true;
                        }
                        else
                        {
                            MessageBox.Show("Not enough stock of items in the inventory!");
                            return false;
                        }

                    }
                    else
                    {
                        MessageBox.Show("Item is already in the invoice!");
                        return false;
                    }
                }
            }
            MessageBox.Show("Item does not exist in the inventory!");
            return false;
        }

        internal object GetInvoice()
        {
            return finalInvoice.ToArray<InvoiceItem>();
        }

        internal string GetInvoiceTotal()
        {
            double invoiceTotal = 0;
            foreach (InvoiceItem invoiceItem in finalInvoice)
            {
                invoiceTotal = invoiceTotal + invoiceItem.SubTotal;
            }
            return invoiceTotal.ToString();
        }

        private double getSubTotal(double price, int quantitySold)
        {
            return price * quantitySold;
        }

    }
}
