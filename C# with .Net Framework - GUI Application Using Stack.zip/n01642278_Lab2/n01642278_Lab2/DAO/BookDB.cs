﻿using n01642278_Lab2.Business;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace n01642278_Lab2.DAO
{
    internal class BookDB
    {
        Stack<Book> booksStack = new Stack<Book>();
        internal bool AddNewBook(Book newBook)
        {
            if (booksStack.Contains(newBook))
            {
                return false;
            }
            else
            {
                booksStack.Push(newBook);
                return true;
            }
        }

        internal Book[] FindByISBN(string iSBN)
        {
            Book[] isbnArray = booksStack.ToArray();
            Stack<Book> iSBNStack = new Stack<Book>();
            for (int i = 0; i < isbnArray.Length; i++)
            {
                if (isbnArray[i].ISBN == iSBN)
                {
                    iSBNStack.Push(isbnArray[i]);
                }
            }
            return iSBNStack.ToArray();
        }

        internal Book[] GetAllBooks()
        {
            return booksStack.ToArray();
        }

        internal int GetBooksCount()
        {
            return (booksStack.Count);
        }

        internal Book[] GetFoundBook(Book findbook)
        {
            Stack<Book> foundStack = new Stack<Book>();
            if (booksStack.Contains(findbook))
            {
                foundStack.Push(findbook);
            }
            return foundStack.ToArray();
        }

        internal void RemoveAllBooks()
        {
            booksStack.Clear();
        }

        internal bool RemoveOldBook(Book oldBook)
        {
            if (booksStack.Contains(oldBook))
            {
                booksStack.Pop();
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
