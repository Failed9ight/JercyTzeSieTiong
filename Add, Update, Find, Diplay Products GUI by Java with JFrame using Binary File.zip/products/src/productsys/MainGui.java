package productsys;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;


public class MainGui extends JFrame {
	private static final long serialVersionUID = 1L;
	
	//An Array list to store product objects, it is static so it can be accessed by other clases:
    static ArrayList<Product> productsArrayList = new ArrayList<>();
    //Array List getter:
    public ArrayList<Product> getproductsArrayList() {
        return productsArrayList;
    }
	
	//Containers and Components
	private JMenuBar menuBar;
	private JMenu file;
	private JMenu product;
	private JPanel mainPanel;
	private JLabel titleLabel;
	Color color = new Color(80,80,80);
	
	//Constructor:	
	public MainGui(){
		//JFrame set methods:
		setTitle("****** PRODUCT MANAGEMENT SYSTEM ******");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(800, 500);
		setResizable(false);
		setLocationRelativeTo(null);
		
		//Creating component instances:
		menuBar = new JMenuBar();
		file = new JMenu("File");
		product = new JMenu("Product");
		mainPanel = new JPanel();
		//Parameters of the layout center content
		mainPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 180));
		mainPanel.setBackground(color);
		titleLabel = new JLabel("Product Management System");
		titleLabel.setForeground(new Color(220,175,55));
		Font titleFont = titleLabel.getFont(); //Font class to change size and weight
		titleLabel.setFont(new Font(titleFont.getFontName(), Font.BOLD, 34));
		JLabel authorsLabel = new JLabel("------ Developed by GROUP 1 - ITC 5201-0GB - OCT 2023 ------");
		authorsLabel.setForeground(new Color(180,180,180));
		
		//Adding menus, containers and components to the frame
		setJMenuBar(menuBar);
		
		menuBar.add(file);
		file.add(createFileMenuItem());
		menuBar.add(product);
		product.add(createProductMenuItemAdd());
		product.add(createProductMenuItemFind());
		add(mainPanel);
		mainPanel.add(titleLabel, BorderLayout.CENTER);
		mainPanel.add(authorsLabel,BorderLayout.SOUTH);
		
		loadProductsBinaryFile();
		
	}
	//Method to create the file menu item Exit
		public JMenuItem createFileMenuItem() {
			JMenuItem itemExit = new JMenuItem("Exit");
			// creating a subclass that implements Action listener to instantiate it afterwards
			// it will contain a method to exit the app
			class MenuItemListener implements ActionListener {	
				public void actionPerformed(ActionEvent e) {
					System.exit(0);// exit
				}
			}
			// instantiating the actionListener for the exit menuItem
			ActionListener listener = new MenuItemListener();
			itemExit.addActionListener(listener);
			return (itemExit);
		}
		
	//Method to create the Product menu item Add / Update
		public JMenuItem createProductMenuItemAdd() {
			JMenuItem itemAddOrUpdate = new JMenuItem("Add / Update");
			// creating a subclass that implements Action listener to instantiate it afterwards
			// it will contain a method to open the add / update frame
			class MenuItemListener implements ActionListener {	
				public void actionPerformed(ActionEvent e) {
					AddOrUpdate addOrUpdateFrame = new AddOrUpdate();
					addOrUpdateFrame.setVisible(true);
				}
			}
			// instantiating the actionListener for the add/update menuItem
			ActionListener listener = new MenuItemListener();
			itemAddOrUpdate.addActionListener(listener);
			return (itemAddOrUpdate);
		}
		
	//Method to create the Product menu item Find / Display
		public JMenuItem createProductMenuItemFind() {
			JMenuItem itemFindOrDisplay = new JMenuItem("Find / Display");
			// creating a subclass that implements Action listener to instantiate it afterwards
			// it will contain a method to open the Find / Display frame
			class MenuItemListener implements ActionListener {	
				public void actionPerformed(ActionEvent e) {
					FindOrDisplay findOrDisplayFrame = new FindOrDisplay();
					findOrDisplayFrame.setVisible(true);
				}
			}
			// instantiating the actionListener for the find menuItem
			ActionListener listener = new MenuItemListener();
			itemFindOrDisplay.addActionListener(listener);
			return (itemFindOrDisplay);
		}

		
		//Method to load products from the binary file - to be revised!!
	    private void loadProductsBinaryFile() {
	        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream("src\\product.dat"))) {
	        	//Not sure if this will work
	        	productsArrayList = (ArrayList<Product>) input.readObject();
	        	JOptionPane.showMessageDialog(this, "Products loaded successfully from binary file!");
	        } catch (IOException | ClassNotFoundException e) {
	        	JOptionPane.showMessageDialog(this, "Error loading products from binary file: " + e.getMessage());
	        }
	    }
	
		
	
	public static void main(String[] args) {

		MainGui mainGui = new MainGui();
		mainGui.setVisible(true);
	}

	
	
}
