﻿using n01642278_Assignment3.Database;
using n01642278_Assignment3.Items;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace n01642278_Assignment3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            //Initializing the Inventory
            itemDBObj.InitializeInventory();

            InitialDisplayInventory();
        }

        //Restrict access to the modification of initial inventory grid view
        private void InitialDisplayInventory()
        {
            gvInventory.DataSource = itemDBObj.GetItemsList();

        }

        ItemDB itemDBObj = new ItemDB();

        // Inventory Item Buttons and Methods
        private void btnAddItem_Click(object sender, EventArgs e)
        {
            Item addItem = GetItem();

            if (addItem != null)
            {
                bool success = itemDBObj.AddItem(addItem);

                if (success)
                {
                    MessageBox.Show("Item added successfully!");
                }
            }
            gvInventory.DataSource = itemDBObj.GetItemsList();
            gvInventory.Refresh();

        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            string itemCode = tbItemCode.Text;

            Item isFound = itemDBObj.FindItem(itemCode);

            if (isFound == null)
            {
                MessageBox.Show("Item doesn't exists!");
            }
            else
            {
                MessageBox.Show("Item found!");
                tbItemCode.Text = isFound.ItemCode;
                tbName.Text = isFound.Name;
                tbUnitPrice.Text = isFound.Price.ToString();
                tbQuantity.Text = isFound.QuantityInStock.ToString();
            }


        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                string targetItemCode = tbItemCode.Text;
                double targetItemPrice = double.Parse(tbUnitPrice.Text);
                int targetItemQuantity = int.Parse(tbQuantity.Text);

                Item targetItem = itemDBObj.Update(targetItemCode, targetItemPrice, 
                    targetItemQuantity);

                if (targetItem == null)
                {
                    MessageBox.Show("Item does not exist!");
                }
                else
                {
                    MessageBox.Show("Item updated successfully!");
                }
                gvInventory.DataSource = itemDBObj.GetItemsList();
                gvInventory.Refresh();
            }
            catch (FormatException ex)
            {
                MessageBox.Show("Invalid input of price and/or quantity! " + ex.Message +
                    " Please enter details for item code, unit price and quantity (Item name is" +
                    " not updatable)!" +
                    " Make sure the inputs of quantity and/or price are in correct format " +
                    "(price: double, quantity: integer)!");
            }

        }

        private Item GetItem()
        {
            try
            {
                Item item = new Item();
                item.ItemCode = tbItemCode.Text;
                item.Name = tbName.Text;
                item.QuantityInStock = int.Parse(tbQuantity.Text);
                item.Price = double.Parse(tbUnitPrice.Text);

                return item;
            }
            catch (FormatException ex)
            {
                MessageBox.Show("Invalid input! " + ex.Message + " Please enter all details! " +
                    "Make sure correct data types are entered for Quantity and Unit Price (" +
                    "integer and double, respectively)!");

                return null;
            }
        }


        // Invoice Item Buttons and Methods
        private void btnAddToInvoice_Click(object sender, EventArgs e)
        {
            InvoiceItem addInvoiceItem = GetInvoiceItem();

            if (addInvoiceItem != null)
            {
                bool success = itemDBObj.AddInvoiceItem(addInvoiceItem.Name, 
                    addInvoiceItem.QuantitySold);

                if (success)
                {
                    MessageBox.Show("Item added successfully!");
                }
            }
        }

        private InvoiceItem GetInvoiceItem()
        {
            try
            {
                InvoiceItem invoiceItem = new InvoiceItem();
                invoiceItem.Name = tbInvoiceItem.Text;
                invoiceItem.QuantitySold = int.Parse(tbQuantitySold.Text);
                return invoiceItem;
            }
            catch (FormatException ex)
            {
                MessageBox.Show("Invalid input! " + ex.Message + " Please enter all details!"
                    + " Make sure to keep quantity sold a positive whole number!");
                return null;
            }
        }

        private void btnDisplay2_Click(object sender, EventArgs e)
        {
            gvInventory.DataSource = itemDBObj.GetItemsList();
            gvInventory.Refresh();
            gvInvoice.DataSource = itemDBObj.GetInvoice();
            gvInvoice.Refresh();

            tbInvoiceTotal.Text = itemDBObj.GetInvoiceTotal();
        }
    }
}