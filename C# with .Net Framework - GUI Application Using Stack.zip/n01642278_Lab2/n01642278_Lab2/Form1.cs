﻿using n01642278_Lab2.Business;
using n01642278_Lab2.DAO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace n01642278_Lab2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        BookDB bookDB = new BookDB();

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Book newBook = new Book();
            newBook.ISBN = tbISBN.Text;
            newBook.Name = tbName.Text;
            newBook.Author = tbAuthor.Text;
            newBook.NumberofPages = int.Parse(tbPages.Text);

            bool success = bookDB.AddNewBook(newBook);

            if (success)
            {
                MessageBox.Show("Book is added successfully", "Add Book", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Book is failed to be added", "Add Book", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            Book[] bookArray = bookDB.GetAllBooks();
            
            if (bookArray != null)
            {
                gvBooks.DataSource = bookArray;
                gvBooks.Refresh();
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            Book oldBook = new Book();
            oldBook.ISBN = tbISBN.Text;
            oldBook.Name = tbName.Text;
            oldBook.Author = tbAuthor.Text;
            oldBook.NumberofPages = int.Parse(tbPages.Text);

            bool remove = bookDB.RemoveOldBook(oldBook);

            if (remove)
            {
                MessageBox.Show("Book is removed", "Remove Book", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Book is failed to be removed", "Remove Book", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnGetCount_Click(object sender, EventArgs e)
        {
            int count = bookDB.GetBooksCount();

            MessageBox.Show("The Total book(s) in the database is: " + count, "Count Books", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button1_Click(object sender, EventArgs e) //This is Remove All Books Button.
        {
            bookDB.RemoveAllBooks();

            MessageBox.Show("All the books are successfully removed", "Remove All Books", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnFindBook_Click(object sender, EventArgs e)
        {
            Book findBook = new Book();
            findBook.ISBN = tbISBN.Text;
            findBook.Name = tbName.Text;
            findBook.Author = tbAuthor.Text;
            findBook.NumberofPages = int.Parse(tbPages.Text);

            // bool find = bookDB.FindBook(findBook);

            Book[] foundBook = bookDB.GetFoundBook(findBook);

            if (foundBook != null)
            {
                gvBooks.DataSource = foundBook;
                gvBooks.Refresh();
            }

        }

        private void btnISBN_Click(object sender, EventArgs e)
        {
            Book findISBN = new Book();
            findISBN.ISBN = tbISBN.Text;

            Book[] isbnBook = bookDB.FindByISBN(findISBN.ISBN);

            if (isbnBook != null)
            {
                gvBooks.DataSource = isbnBook;
                gvBooks.Refresh();
            }
        }
    }
}
