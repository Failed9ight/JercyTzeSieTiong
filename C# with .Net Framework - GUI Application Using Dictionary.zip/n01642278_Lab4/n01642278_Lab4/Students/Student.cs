﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace n01642278_Lab4.Students
{
    internal class Student
    {
        public String StudentID { get; set; }

        public String Name { get; set; }

        public int Age { get; set; }

        public String Address { get; set; }
    }
}
