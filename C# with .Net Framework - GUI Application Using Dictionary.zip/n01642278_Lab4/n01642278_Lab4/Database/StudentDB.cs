﻿using n01642278_Lab4.Students;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace n01642278_Lab4.Database
{
    internal class StudentDB
    {
        Dictionary<string, Student> studentDict = new Dictionary<string, Student>();

        internal bool AddStudent(Student studentObj)
        {
            if (studentDict.ContainsKey(studentObj.StudentID))
            {
                return false;
            }
            else
            {
                studentDict.Add(studentObj.StudentID, studentObj);
                return true;
            }
        }

        internal object GetAllStudents()
        {
            return studentDict.Values.ToArray();
        }

        internal Student FindStudentByID(string studentID)
        {
            if (studentDict.ContainsKey(studentID))
            {
                return studentDict[studentID];
            }
            else
            {
                return null;
            }
        }

        internal bool RemoveStudentByID(string studentID)
        {
            bool removed = studentDict.Remove(studentID);

            return removed;
        }

        internal string[] GetStudentID()
        {
            Student[] students = studentDict.Values.ToArray();
            List<string> studentIDs = new List<string>();

            foreach (Student student in students)
            {
                studentIDs.Add(student.StudentID);
            }

            return studentIDs.ToArray();
        }

        internal void RemoveAllStudent()
        {
            studentDict.Clear();
        }
    }
}
