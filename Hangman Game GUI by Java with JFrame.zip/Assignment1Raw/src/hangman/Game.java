package hangman;
//***************************************************************************
//ITC 5201 Assignemnt 1                                                     *
//Developed and Designed by Group1											*
//-Roger Paredes, N01602284													*
//-Jercy Tiong, N01642278													*
//-Ryan Ancheta, N01598445													*
//-Section: 0GB                                                             *
//-Explain the logic: Our group basically constructs a GUI to form a hangman*
// with Java and Jframe extensions. We have a game frame that contains		*
// multiple panels, and each panel with specific GUI components like label,	*
// text-fields, etc. Then, when action listeners on the specific buttons are*
// triggered, the actionPerformed are triggered at the same time to call	*
// the function of the hangman game. More of how the game works (rules) will*
// be explained in the recorded video.										*
//***************************************************************************
//importing libraries from Java API
import javax.swing.*;
import java.io.PrintWriter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

//create a class name Game that will extends JFrame Class for GUI
public class Game extends JFrame {
	//object serialization
	private static final long serialVersionUID = 1L;
	
	//An ArrayList that will hold the words on the hangman.txt file:
	ArrayList<String> wordsArrayList = new ArrayList<>();
	//variable that will hold the word that the user will guess
	private String currentWord;
	//variable that will mask the current word with "*"
	private char[] wordState;
	//variable to count the word missed by user
	private int misses;
	//Declaring an ArrayList to store the entered characters of each randomly picked word:
	private ArrayList<Character> enteredLetters;
	
	//Declaring the Gui components:
	private JLabel welcomeLabel;
	private JLabel instructionsLabel;
	private JLabel logoLabel;
	private JLabel wordLabel;
	private JLabel missesLabel;
	private JLabel picturePngLabel;
	private JTextField inputField;
	JButton enterBtn;
	private JLabel authorsLabel;
	//declaring Panels for the layout
	JPanel upperPanel;
	JPanel centralPanel;
	JPanel centralComponentsPanel;
	JPanel imagePanel;
	JPanel bottomPanel;
	//declaring icons
	ImageIcon logo;
	ImageIcon icon;
	//creating object color with color darkgray
	Color darkGray1 = new Color (40,40,40);


	//Constructor class:
	public Game() {
		//calling method scanWordsFromTxt that will get the randomized word form txt file
		scanWordsFromTxt();
		//creating an arraylist object that store users letter guesses this will help 
		//us to check if the user already entered the letter character
		enteredLetters = new ArrayList<>();
		//initializing misses variable with 0 that will increment every time made an incorrect guess
		//also acts as counter so if the user has 6 misses the game will end 
		misses = 0;
		
		//calling method createGUI to create the GUI for the hangman game
		createGui();
		//calling method activateBtn this will give functionality to our enterBtn in our GUI 
		activateBtn();
		//calling newGame method that will ask user to play another when the user lose or win
		newGame();
	}
	
	//creates a method that will give functionality to our enterBtn
	private void activateBtn() {		
		//adding actionlistener to our button when clicked
		enterBtn.addActionListener(new ActionListener() {
			@Override
			//implementing ActionEvent by using anonymous inner class that will trigger event when button is clicked
			public void actionPerformed(ActionEvent e) {
				///calling method guessLogic when the enterBtn is clicked
				guessLogic();
			}
		});
	}
	
	//Method to create the Graphical User interface (needs the class to extend JFrame):
	public void createGui() {
		//setting the panel with BorderLayout with hgap of 20 and vgap of 40
		setLayout(new BorderLayout(20, 40));
		
		//To set a default font size for all text in the UIManager
        int fontSize = 14; // Change this to your desired font size
        Font newFont = UIManager.getFont("Label.font").deriveFont((float) fontSize);
        UIManager.put("Label.font", newFont);
        UIManager.put("TextField.font", newFont);
        UIManager.put("TextArea.font", newFont);
        UIManager.put("Button.font", newFont);
        //creating a new logo object with parameter of file path
		logo = new ImageIcon("src\\hangman\\images\\hangmanlogo.png");
		logoLabel = new JLabel();
		//setting Icon with parameter as object logo
		logoLabel.setIcon(logo);
		//label to welcome users
		welcomeLabel = new JLabel(" Are you daring enough to play?");
		//changing the foreground color of welcomeLabel to white
		welcomeLabel.setForeground(Color.white);
		//label for instructions how to play the game
		instructionsLabel = new JLabel(" > You have 6 shots missed per word. Good Luck!");
		//changing the foreground color of instructionLabel to gray
		instructionsLabel.setForeground(Color.gray);
		//label that will hold the currentWord which the user will guess
		wordLabel = new JLabel("?");
		//label that holds misses counter 
		missesLabel = new JLabel();
		picturePngLabel = new JLabel();
		//text field where the user will type there guess letter with parameter of 2 column
		inputField = new JTextField(2);
		//button that when clicked gameLogic method will be called and has text parameter "Try"
		enterBtn = new JButton("Try");
		//creating panels
		upperPanel = new JPanel();
		centralPanel = new JPanel();
		centralComponentsPanel = new JPanel();
		//we want to all the components in this panel at the center
		centralComponentsPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 7, 5));
		imagePanel = new JPanel();
		//all components to be on the left side
		imagePanel.setLayout(new FlowLayout(FlowLayout.LEFT, 40, 40));
		bottomPanel = new JPanel();
		authorsLabel = new JLabel(" Developed by GROUP 1 - ITC 5201-0GB - OCT 2023");
		authorsLabel.setForeground(Color.gray);
		
		
		//upperPanel with a set height
		upperPanel.setPreferredSize(new Dimension(0, 200));
		//adding components in upperPanel
		upperPanel.add(logoLabel);
		upperPanel.add(welcomeLabel);
		upperPanel.add(instructionsLabel);
		upperPanel.setBackground(darkGray1);
		
		
		//adding components to the centralComponentPanel
		centralComponentsPanel.add(wordLabel);
		centralComponentsPanel.add(inputField);
		centralComponentsPanel.add(enterBtn);
		centralComponentsPanel.add(missesLabel);
		//adding components to the centralPanel
		centralPanel.add(centralComponentsPanel);
		imagePanel.add(picturePngLabel);
		centralPanel.add(imagePanel);
		//adding components to the bottom panel
		bottomPanel.add(authorsLabel);
		bottomPanel.setBackground(darkGray1);
		//addding upperPanel to main parent panel at the notrthside
		add(upperPanel, BorderLayout.NORTH);
		//addding centralPanel to main parent panel at the center side
		add(centralPanel, BorderLayout.CENTER);
		//addding bottomPanel to main parent panel at thesouth side
		add(bottomPanel, BorderLayout.SOUTH);
		//creating button to ask the user to add word when the game ended
		JButton addWordBtn = new JButton("Add Word");
		//adding a listener when the add word button is click
		addWordBtn.addActionListener(new ActionListener() {
			//implementing ActionEvent using anonymous inner class
		    @Override
		    public void actionPerformed(ActionEvent e) {
		    	//calling addword method when the addwordBtn is clicked
		        addWord();
		    }
		});
		
		
	}
	
	//Method reads the .txt file and updates the wordsArrayList:
	private void scanWordsFromTxt() {	
		//exception handler for exception filenotfound
		try {
		//creating an object that will store the words from the txt file
		File wordsFile = new File("src\\hangman\\hangman.txt");
		//creating object to read the txt file
		Scanner textScanner = new Scanner(wordsFile);
			
			//Loop to add each word as long as there is another line:
			while(textScanner.hasNextLine()) {
				wordsArrayList.add(textScanner.nextLine());
			}	
			//cant implent autoclose so we need to close manually
			textScanner.close();
		}	//catch block with message dialog
		catch (java.io.FileNotFoundException ex ) {
			JOptionPane.showMessageDialog(null, "The hangman.txt source file with the words for the game was not found. Either Group1 or you messed up the files. :(", "Oh, snap! - ERROR", JOptionPane.INFORMATION_MESSAGE);
			ex.printStackTrace();
		}
	}
	
	//method for word randomizer:
	private String getRandomWord() {	
		//will generate a random index within the valid range of arraylist then get the word and
		//return the word in lower case
		String randomWord = wordsArrayList.get((int)(Math.random() * wordsArrayList.size()));
		return randomWord.toLowerCase();
	}
	
	//Method to start the game, invoke the random word and display "*" for its length
	private void newGame() {
		//calling getrandomword method and assigning it to current word
		currentWord = getRandomWord();
		//masking every char index with "*" for its length
		wordState = new char[currentWord.length()];
		for (int i = 0; i < currentWord.length(); i++) {
			wordState[i] = '*';
		}
		
		if (wordLabel != null) {
			//assigning the wordstate to the component wordlabel in GUI
			wordLabel.setText(new String(wordState));
			//couter for misses of user
			misses = 0;
			//textfield for user to enter letter character
			enteredLetters.clear();
			//assigning missess counter to component missesLabel in GUI
			missesLabel.setText("Misses: " + misses);
			
			// This is so there's a placeholder empty png in place and components alignment wont reorder after first miss:
			ImageIcon nullIcon = new ImageIcon("src\\hangman\\images\\hangman0.png");
			picturePngLabel.setIcon(nullIcon);
			inputField.setText("");
		}	
	}

	//Game's logic:
	private void guessLogic() {
		//assigning variable to get the input from user from text field and converting it to lowercase
		String input = inputField.getText().toLowerCase();
		//to make sure that the user will input only single character or just letter character
		if (input.length() != 1 || !Character.isLetter(input.charAt(0))) {
			JOptionPane.showMessageDialog(this, "Please enter a single letter from a to z.");
			return;
		}
		//assigning variable for input from user to check if the user already used that letter
		char guess = input.charAt(0);
		//to make sure the wont enter the same letter the second time
		if (enteredLetters.contains(guess)) {
			JOptionPane.showMessageDialog(this, "You already tried this letter. PLease try another.");
			return;
		}
		//adding the users guesses to the arraylist enteredLetters
		enteredLetters.add(guess);
		//creating a boolean variable found and setting it to false
		boolean found = false;
		//loop to iterate through the letters of current word and if the user guess is found
		//will remove the masking "*" from word state will set the found to true
		for (int i = 0; i < currentWord.length(); i++) {
			if (currentWord.charAt(i) == guess) {
				wordState[i] = guess;
				found = true;
			}
		}
		//if guess of the user is not found increment 1 to misses counter and 
		//add picture of the hangman.png
		if (!found) {
			misses = misses + 1;
			updateHangmanPng();
		}
		//updating the components of GUI after user move
		wordLabel.setText(new String(wordState));
		missesLabel.setText("Misses: " + misses);
		//checking if the wordstate is equals to the currentword the player wins
		if (new String(wordState).equals(currentWord)) {
			//message telling the user won and asking if it wants to play again
			int option = JOptionPane.showConfirmDialog(this, "You won!!!!!!" + "\n" + "Play again?", "Congrats!",
					JOptionPane.YES_NO_OPTION);
			//calling addWord method whether the user wants to play again or not
			addWord();
			//if the user select yes from dialog will call method newGame and will start a new game
			if (option == JOptionPane.YES_OPTION) {
				newGame();
			//is user select no will terminate the program
			} else {
				System.exit(0);
			}
		//if the misses equals to 6 will show message that the user lose
		} else if (misses == 6) {
			JOptionPane.showMessageDialog(this, "You are Dead!!!!!!" + "\n" + "The word was: " + currentWord);
			int option = JOptionPane.showConfirmDialog(this, "Want to play again?", "Game Over", JOptionPane.YES_NO_OPTION);
			//calling addWord method whether the user wants to play again or not
			addWord();
			//if the user select yes from dialog will call method newGame and will start a new game
			if (option == JOptionPane.YES_OPTION) {
				newGame();
			//if user select no will terminate the program	
			} else {
				System.exit(0);
			}
		}
		
	}
	//Method to change the image of the hangman according to misses:
	private void updateHangmanPng() {
		if (misses == 6) {
			icon = new ImageIcon("src\\hangman\\images\\hangman6.png");		
		}
		else if (misses == 5){
			icon = new ImageIcon("src\\hangman\\images\\hangman5.png");
		}
		else if (misses == 4){
			icon = new ImageIcon("src\\hangman\\images\\hangman4.png");	
		}
		else if (misses == 3){
			icon = new ImageIcon("src\\hangman\\images\\hangman3.png");	
		}
		else if (misses == 2){
			icon = new ImageIcon("src\\hangman\\images\\hangman2.png");	
		}			
		else if (misses == 1){
			icon = new ImageIcon("src\\hangman\\images\\hangman1.png");	
		}
		picturePngLabel.setIcon(icon);
	}
	//method to ask the user to addWord and will append the word to hangman.txt file
	private void addWord() {
	    String newWord = JOptionPane.showInputDialog(this, "Enter a new word to add to the list:");
	    //to check the newWord that user has entered is not null and not empty
	    if (newWord != null && !newWord.isEmpty()) {
	    	//try block for exception handling
	        try {
	            //opening the text file for appending the new word
	            PrintWriter writer = new PrintWriter(new FileWriter("src\\hangman\\hangman.txt", true));
	            
	            // adding the new word to the file
	            writer.println(newWord);
	            
	            //closing the writer manually
	            writer.close();
	            
	            //inform the user that the word has been added
	            JOptionPane.showMessageDialog(this, "Word added successfully.");
	            //catch block for IOException
	        } catch (IOException e) {
	            JOptionPane.showMessageDialog(this, "An error occurred while adding the word.");
	        }
	    }
	}

	

}
