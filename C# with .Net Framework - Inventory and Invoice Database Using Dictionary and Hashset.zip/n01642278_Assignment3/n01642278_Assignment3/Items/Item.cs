﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace n01642278_Assignment3.Items
{
    internal class Item
    {
		private string itemCode;

		public string ItemCode
		{
			get { return itemCode; }
			set { itemCode = value; }
		}

		private string name;

		public string Name
		{
			get { return name; }
			set { name = value; }
		}

		private double price;

		public double Price
		{
			get { return price; }
			set { price = value; }
		}

		private int quantityInStock;

		public int QuantityInStock
		{
			get { return quantityInStock; }
			set { quantityInStock = value; }
		}


	}
}
