﻿namespace n01642278_Lab5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gvSet1 = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tbAddSet1 = new System.Windows.Forms.TextBox();
            this.btnAddSet1 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tbAddSet2 = new System.Windows.Forms.TextBox();
            this.btnAddSet2 = new System.Windows.Forms.Button();
            this.gvSet2 = new System.Windows.Forms.DataGridView();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tbAddSet3 = new System.Windows.Forms.TextBox();
            this.btnAddSet3 = new System.Windows.Forms.Button();
            this.gvSet3 = new System.Windows.Forms.DataGridView();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnUniqueSet1 = new System.Windows.Forms.Button();
            this.btnExclude = new System.Windows.Forms.Button();
            this.btnCommon = new System.Windows.Forms.Button();
            this.btnCombination = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.gvResult = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.gvSet1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvSet2)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvSet3)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvResult)).BeginInit();
            this.SuspendLayout();
            // 
            // gvSet1
            // 
            this.gvSet1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvSet1.Location = new System.Drawing.Point(99, 79);
            this.gvSet1.Name = "gvSet1";
            this.gvSet1.RowHeadersWidth = 51;
            this.gvSet1.RowTemplate.Height = 27;
            this.gvSet1.Size = new System.Drawing.Size(218, 123);
            this.gvSet1.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tbAddSet1);
            this.groupBox1.Controls.Add(this.btnAddSet1);
            this.groupBox1.Controls.Add(this.gvSet1);
            this.groupBox1.Font = new System.Drawing.Font("PMingLiU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox1.Location = new System.Drawing.Point(71, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(425, 222);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Set 1";
            // 
            // tbAddSet1
            // 
            this.tbAddSet1.Location = new System.Drawing.Point(183, 43);
            this.tbAddSet1.Name = "tbAddSet1";
            this.tbAddSet1.Size = new System.Drawing.Size(220, 25);
            this.tbAddSet1.TabIndex = 1;
            // 
            // btnAddSet1
            // 
            this.btnAddSet1.Location = new System.Drawing.Point(17, 34);
            this.btnAddSet1.Name = "btnAddSet1";
            this.btnAddSet1.Size = new System.Drawing.Size(140, 39);
            this.btnAddSet1.TabIndex = 0;
            this.btnAddSet1.Text = "Add";
            this.btnAddSet1.UseVisualStyleBackColor = true;
            this.btnAddSet1.Click += new System.EventHandler(this.btnAddSet1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tbAddSet2);
            this.groupBox2.Controls.Add(this.btnAddSet2);
            this.groupBox2.Controls.Add(this.gvSet2);
            this.groupBox2.Font = new System.Drawing.Font("PMingLiU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox2.Location = new System.Drawing.Point(563, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(425, 222);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Set 2";
            // 
            // tbAddSet2
            // 
            this.tbAddSet2.Location = new System.Drawing.Point(183, 43);
            this.tbAddSet2.Name = "tbAddSet2";
            this.tbAddSet2.Size = new System.Drawing.Size(220, 25);
            this.tbAddSet2.TabIndex = 1;
            // 
            // btnAddSet2
            // 
            this.btnAddSet2.Location = new System.Drawing.Point(17, 34);
            this.btnAddSet2.Name = "btnAddSet2";
            this.btnAddSet2.Size = new System.Drawing.Size(140, 39);
            this.btnAddSet2.TabIndex = 0;
            this.btnAddSet2.Text = "Add";
            this.btnAddSet2.UseVisualStyleBackColor = true;
            this.btnAddSet2.Click += new System.EventHandler(this.btnAddSet2_Click);
            // 
            // gvSet2
            // 
            this.gvSet2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvSet2.Location = new System.Drawing.Point(100, 79);
            this.gvSet2.Name = "gvSet2";
            this.gvSet2.RowHeadersWidth = 51;
            this.gvSet2.RowTemplate.Height = 27;
            this.gvSet2.Size = new System.Drawing.Size(218, 123);
            this.gvSet2.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tbAddSet3);
            this.groupBox3.Controls.Add(this.btnAddSet3);
            this.groupBox3.Controls.Add(this.gvSet3);
            this.groupBox3.Font = new System.Drawing.Font("PMingLiU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox3.Location = new System.Drawing.Point(12, 268);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(425, 222);
            this.groupBox3.TabIndex = 4;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Set 3";
            // 
            // tbAddSet3
            // 
            this.tbAddSet3.Location = new System.Drawing.Point(183, 43);
            this.tbAddSet3.Name = "tbAddSet3";
            this.tbAddSet3.Size = new System.Drawing.Size(220, 25);
            this.tbAddSet3.TabIndex = 1;
            // 
            // btnAddSet3
            // 
            this.btnAddSet3.Location = new System.Drawing.Point(17, 34);
            this.btnAddSet3.Name = "btnAddSet3";
            this.btnAddSet3.Size = new System.Drawing.Size(140, 39);
            this.btnAddSet3.TabIndex = 0;
            this.btnAddSet3.Text = "Add";
            this.btnAddSet3.UseVisualStyleBackColor = true;
            this.btnAddSet3.Click += new System.EventHandler(this.btnAddSet3_Click);
            // 
            // gvSet3
            // 
            this.gvSet3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvSet3.Location = new System.Drawing.Point(99, 79);
            this.gvSet3.Name = "gvSet3";
            this.gvSet3.RowHeadersWidth = 51;
            this.gvSet3.RowTemplate.Height = 27;
            this.gvSet3.Size = new System.Drawing.Size(218, 123);
            this.gvSet3.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnUniqueSet1);
            this.groupBox4.Controls.Add(this.btnExclude);
            this.groupBox4.Controls.Add(this.btnCommon);
            this.groupBox4.Controls.Add(this.btnCombination);
            this.groupBox4.Font = new System.Drawing.Font("PMingLiU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox4.Location = new System.Drawing.Point(475, 278);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(237, 212);
            this.groupBox4.TabIndex = 5;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Set Operation";
            // 
            // btnUniqueSet1
            // 
            this.btnUniqueSet1.Location = new System.Drawing.Point(17, 163);
            this.btnUniqueSet1.Name = "btnUniqueSet1";
            this.btnUniqueSet1.Size = new System.Drawing.Size(201, 37);
            this.btnUniqueSet1.TabIndex = 3;
            this.btnUniqueSet1.Text = "Unique in Set 1";
            this.btnUniqueSet1.UseVisualStyleBackColor = true;
            this.btnUniqueSet1.Click += new System.EventHandler(this.btnUniqueSet1_Click);
            // 
            // btnExclude
            // 
            this.btnExclude.Location = new System.Drawing.Point(17, 123);
            this.btnExclude.Name = "btnExclude";
            this.btnExclude.Size = new System.Drawing.Size(201, 23);
            this.btnExclude.TabIndex = 2;
            this.btnExclude.Text = "Exclude Common";
            this.btnExclude.UseVisualStyleBackColor = true;
            this.btnExclude.Click += new System.EventHandler(this.btnExclude_Click);
            // 
            // btnCommon
            // 
            this.btnCommon.Location = new System.Drawing.Point(17, 79);
            this.btnCommon.Name = "btnCommon";
            this.btnCommon.Size = new System.Drawing.Size(201, 23);
            this.btnCommon.TabIndex = 1;
            this.btnCommon.Text = "Common";
            this.btnCommon.UseVisualStyleBackColor = true;
            this.btnCommon.Click += new System.EventHandler(this.btnCommon_Click);
            // 
            // btnCombination
            // 
            this.btnCombination.Location = new System.Drawing.Point(17, 32);
            this.btnCombination.Name = "btnCombination";
            this.btnCombination.Size = new System.Drawing.Size(201, 23);
            this.btnCombination.TabIndex = 0;
            this.btnCombination.Text = "Combination";
            this.btnCombination.UseVisualStyleBackColor = true;
            this.btnCombination.Click += new System.EventHandler(this.btnCombination_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.gvResult);
            this.groupBox5.Font = new System.Drawing.Font("PMingLiU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox5.Location = new System.Drawing.Point(728, 278);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(299, 212);
            this.groupBox5.TabIndex = 6;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Result Set";
            // 
            // gvResult
            // 
            this.gvResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvResult.Location = new System.Drawing.Point(9, 27);
            this.gvResult.Name = "gvResult";
            this.gvResult.RowHeadersWidth = 51;
            this.gvResult.RowTemplate.Height = 27;
            this.gvResult.Size = new System.Drawing.Size(289, 173);
            this.gvResult.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1039, 561);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.gvSet1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvSet2)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvSet3)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gvResult)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView gvSet1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox tbAddSet1;
        private System.Windows.Forms.Button btnAddSet1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox tbAddSet2;
        private System.Windows.Forms.Button btnAddSet2;
        private System.Windows.Forms.DataGridView gvSet2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox tbAddSet3;
        private System.Windows.Forms.Button btnAddSet3;
        private System.Windows.Forms.DataGridView gvSet3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnUniqueSet1;
        private System.Windows.Forms.Button btnExclude;
        private System.Windows.Forms.Button btnCommon;
        private System.Windows.Forms.Button btnCombination;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.DataGridView gvResult;
    }
}

