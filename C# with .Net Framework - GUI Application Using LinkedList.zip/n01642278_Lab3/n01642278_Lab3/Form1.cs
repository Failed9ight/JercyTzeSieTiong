﻿using n01642278_Lab3.Business;
using n01642278_Lab3.DB;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace n01642278_Lab3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        CoachDB coaches = new CoachDB();

        private void btnAddFirst_Click(object sender, EventArgs e)
        {
            if(tbCoachID.Text.Length > 0 && tbCoachType.Text.Length > 0 && tbLoadCapacity.Text.Length > 0)
            {
                TrainCoach newCoach = new TrainCoach();
                newCoach.CoachID = int.Parse(tbCoachID.Text);
                newCoach.LoadCapacity = double.Parse(tbLoadCapacity.Text);
                newCoach.CoachType = tbCoachType.Text;

                // LinkedListNode<TrainCoach> node = coaches.AddCoachAtFirst(newCoach);

                bool success = coaches.AddCoachAtFirst(newCoach);

                if(success)
                {
                    MessageBox.Show("Added successfully");
                }
                else
                {
                    MessageBox.Show("Error, coach id already existed");
                }
            }
            else
            {
                MessageBox.Show("Please enter all details!");
            }
        }

        private void btnRefreshData_Click(object sender, EventArgs e)
        {
            gvCoach.DataSource = coaches.GetAllData();
            gvCoach.Refresh();
        }

        private void btnRemoveBefore_Click(object sender, EventArgs e)
        {
            if (tbTargetCoachID.Text.Length > 0)
            {
                int targetCoachID = int.Parse(tbTargetCoachID.Text);
                bool success = coaches.RemoveNodeBefore(targetCoachID);
                if (success)
                {
                    MessageBox.Show("Remove before Successful");
                }
                else
                {
                    MessageBox.Show("Remove before not successful");
                }
            }
            else
            {
                MessageBox.Show("Enter correct target coach id");
            }
        }

        private void btnAddLast_Click(object sender, EventArgs e)
        {
            if (tbCoachID.Text.Length > 0 && tbCoachType.Text.Length > 0 && tbLoadCapacity.Text.Length > 0)
            {
                TrainCoach newCoach = new TrainCoach();
                newCoach.CoachID = int.Parse(tbCoachID.Text);
                newCoach.LoadCapacity = double.Parse(tbLoadCapacity.Text);
                newCoach.CoachType = tbCoachType.Text;

                bool success = coaches.AddCoachAtLast(newCoach);

                if (success)
                {
                    MessageBox.Show("Added successfully");
                }
                else
                {
                    MessageBox.Show("Error, coach iD already existed");
                }
            }
            else
            {
                MessageBox.Show("Please enter all details!");
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (tbCoachID.Text.Length > 0 && tbCoachType.Text.Length > 0 && tbLoadCapacity.Text.Length > 0)
            {
                TrainCoach existedCoach = new TrainCoach();
                existedCoach.CoachID = int.Parse(tbCoachID.Text);
                existedCoach.LoadCapacity = double.Parse(tbLoadCapacity.Text);
                existedCoach.CoachType = tbCoachType.Text;

                bool success = coaches.RemoveCoach(existedCoach);

                if (success)
                {
                    MessageBox.Show("Remove successfully");
                }
                else
                {
                    MessageBox.Show("Error, coach id does not existed");
                }
            }
            else
            {
                MessageBox.Show("Please enter correct details!");
            }
        }

        private void btnRemoveAfter_Click(object sender, EventArgs e)
        {
            if (tbTargetCoachID.Text.Length > 0)
            {
                int targetCoachID = int.Parse(tbTargetCoachID.Text);
                bool success = coaches.RemoveNodeAfter(targetCoachID);

                if (success)
                {
                    MessageBox.Show("Remove after successful");
                }
                else
                {
                    MessageBox.Show("Remove after not successful");
                }
            }
            else
            {
                MessageBox.Show("Enter correct target coach id");
            }
        }

        private void btnAddBefore_Click(object sender, EventArgs e)
        {
            if (tbCoachID.Text.Length > 0 && tbCoachType.Text.Length > 0 && tbLoadCapacity.Text.Length > 0 && tbTargetCoachID.Text.Length > 0)
            {
                TrainCoach newCoach = new TrainCoach();
                newCoach.CoachID = int.Parse(tbCoachID.Text);
                newCoach.LoadCapacity = double.Parse(tbLoadCapacity.Text);
                newCoach.CoachType = tbCoachType.Text;

                int targetCoachID = int.Parse(tbTargetCoachID.Text);
                bool success = coaches.AddNodeBefore(targetCoachID, newCoach);

                if (success)
                {
                    MessageBox.Show("Add before successful");
                }
                else
                {
                    MessageBox.Show("Add before not successful");
                }
            }
            else
            {
                MessageBox.Show("Please check with the coach details and target coach id entered");
            }
        }

        private void btnAddAfter_Click(object sender, EventArgs e)
        {
            if (tbCoachID.Text.Length > 0 && tbCoachType.Text.Length > 0 && tbLoadCapacity.Text.Length > 0 && tbTargetCoachID.Text.Length > 0)
            {
                TrainCoach newCoach = new TrainCoach();
                newCoach.CoachID = int.Parse(tbCoachID.Text);
                newCoach.LoadCapacity = double.Parse(tbLoadCapacity.Text);
                newCoach.CoachType = tbCoachType.Text;

                int targetCoachID = int.Parse(tbTargetCoachID.Text);
                bool success = coaches.AddNodeAfter(targetCoachID, newCoach);

                if (success)
                {
                    MessageBox.Show("Add after successful");
                }
                else
                {
                    MessageBox.Show("Add after not successful");
                }
            }
            else
            {
                MessageBox.Show("Please check with the coach details and target coach id entered");
            }
        }
    }
}
