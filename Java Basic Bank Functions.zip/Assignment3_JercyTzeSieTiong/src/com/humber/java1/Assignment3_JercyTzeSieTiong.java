package com.humber.java1;

import java.util.Scanner;

public class Assignment3_JercyTzeSieTiong {

	public static void main(String[] args) {
		Account accounts[] = new Account[10];
		//Using Loop to Create the Requested 10 Accounts in the Array
		for (int i = 0; i < accounts.length; i++) {
			accounts[i] = new Account(i, 100);
		}
		
		
		//Scanners Ready for User Input later in the ATM Machine Loops.
		Scanner id = new Scanner(System.in);
		Scanner option = new Scanner(System.in);
		Scanner choice2 = new Scanner(System.in);
		Scanner choice3 = new Scanner(System.in);
		
		
		while(true) {
			//Prompt User to Enter Id
			System.out.print("Enter an id: ");
			int inputId = id.nextInt();
			boolean matching = false;
			
			//Check through the Array if User's Input Matches the Id in the Account Array
			for (Account aAccount : accounts) {
				int accountId = aAccount.getId();
				if (accountId == inputId) {
					matching = true;
					break;
				}
			}
			
			while (true) {
				//If the User's Input is Valid, Enter the System for Options of Account
				if (matching) {
					System.out.println("\nMenu\n" + "1: Check Balance\n" + "2: Withdraw\n" +
							"3: deposit\n" + "4: exit");
					System.out.print("Enter a choice: ");
					int choice = option.nextInt();
					
					
					//If the Choice Entered is not Valid, prompted the User with Warning 					Message to Enter Choice Again
					if (choice < 1 || choice > 4) {
						System.out.println("Invalid option! Please re-enter your choice!");
					}
					
					
					//If the Choice Entered is valid
					else {
						
						//1 is Entered, Print Balance of the Id of User's Choice
						if (choice == 1) {
							System.out.printf("The balance is %.2f.\n", 								accounts[inputId].getBalance());
							}
						
						//2 is Entered, Withdraw User's Input Amount from User's Account
						else if (choice == 2) {
							System.out.print("Enter an amount to withdraw: ");
							double inputWithdraw = choice2.nextDouble();
							accounts[inputId].withdraw(inputWithdraw);
						}
						
						//3 is Entered, Deposit User's Input Amount to User's Account
						else if (choice == 3) {
							System.out.print("Enter an amount to deposit: ");
							double inputDeposit = choice3.nextDouble();
							accounts[inputId].deposit(inputDeposit);
						}
						
						//4 is Entered, Quit to Enter Another Id by breaking the Nested Loop.
						else {
							break;
						}
					}
				}
				
				//If the User's Input is not Valid, Print Invalid Message
				else {
					System.out.println("The entered id is invalid, please re-enter!\n");
					break;
				}
			}
		
		}
	}
	
}