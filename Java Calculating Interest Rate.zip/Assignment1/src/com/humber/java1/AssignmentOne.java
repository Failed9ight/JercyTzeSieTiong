package com.humber.java1;

import java.util.Scanner;

/**
 * 
 * @author Name: Jercy Tze Sie Tiong, Student Number N01642278
 * 
 * 		This class creates a financial application that helps to calculate monthly interests
 * 		rate and monthly savings for the first six months of the year, and then
 * 		return/display the saving account value up to the sixth month after the user
 * 		enters the value for monthly saving amount and annual interest rate.
 *
 */

public class AssignmentOne {
	
	public static void main(String[] args) {
		Scanner monthlySaving = new Scanner(System.in);
		System.out.print("What is your monthly saving amount?");
		double inputSaving = monthlySaving.nextDouble();
		
		Scanner annualInterestRate = new Scanner(System.in);
		System.out.print("What is your saving account's annual interest rate in %?");
		double inputInterest = annualInterestRate.nextDouble(); 
		
		double monthlyInterestRate = inputInterest / 100 / 12;
		double firstMonth = inputSaving * (1 + monthlyInterestRate);
		double secondMonth = (inputSaving + firstMonth) * (1 + monthlyInterestRate);
		double thirdMonth = (inputSaving + secondMonth) * (1 + monthlyInterestRate);
		double fourthMonth = (inputSaving + thirdMonth) * (1 + monthlyInterestRate);
		double fifthMonth = (inputSaving + fourthMonth) * (1 + monthlyInterestRate);
		double sixthMonth = (inputSaving + fifthMonth) * (1 + monthlyInterestRate);
		
		System.out.println("After the first month, the value in the saving account becomes " + firstMonth);
		System.out.println("After the second month, the value in the saving account becomes " + secondMonth);
		System.out.println("After the third month, the value in the saving account becomes " + thirdMonth);
		System.out.println("After the fourth month, the value in the saving account becomes " + fourthMonth);
		System.out.println("After the fifth month, the value in the saving account becomes " + fifthMonth);
		System.out.print("After the sixth month, the value in the saving account becomes " + sixthMonth);
	}

}
