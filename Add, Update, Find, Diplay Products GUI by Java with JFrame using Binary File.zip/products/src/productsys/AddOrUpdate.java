package productsys;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.io.*;


public class AddOrUpdate extends JFrame {
	
	//This serialVersion is just to remove a warning lol
	private static final long serialVersionUID = 1L;
	
	//The text fields must be available to all methods:
	JTextField idField;
	JTextField nameField;
	JTextField descField;
	JTextField quantityField;
	JTextField unitPriceField;
	
	//Buttons:
	JButton addBtn;
    JButton updateBtn;
    JButton firstBtn;
    JButton previousBtn;
    JButton nextBtn;
    JButton lastBtn;
		
	
	//Constructor
	public AddOrUpdate() {
		setTitle(" Add/Update Product ");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(660, 350);
		setResizable(false);
		setLocationRelativeTo(null);
		setVisible(true);
		//setLayout(new FlowLayout());
		
		//Components for the left panel:
		JLabel idLabel = new JLabel("Product ID: ");
		idField = new JTextField(20);
		JLabel nameLabel = new JLabel("Product Name: ");
		nameField = new JTextField(20);
		JLabel descLabel = new JLabel("Description: ");
		descField = new JTextField(20);
		
		
		JPanel leftPanel = new JPanel();
		leftPanel.setLayout(new GridLayout(3,1,2,15));
		leftPanel.add(idLabel);
		leftPanel.add(idField);
		leftPanel.add(nameLabel);
		leftPanel.add(nameField);
		leftPanel.add(descLabel);
		leftPanel.add(descField);
		
		//Components for the right panel:
		JLabel quantityLabel = new JLabel("Quantity at hand: ");
		quantityField = new JTextField(5);
		JLabel unitPriceLabel = new JLabel("Unit Price: ");
		unitPriceField = new JTextField(5);
		
		JPanel rightPanel = new JPanel();
		rightPanel.setLayout(new GridLayout(3,2,2,15));
		rightPanel.add(quantityLabel);
		rightPanel.add(quantityField);
		rightPanel.add(unitPriceLabel);
		rightPanel.add(unitPriceField);
		
		//Buttons
		addBtn = new JButton("Add");
	    updateBtn = new JButton("Update");
	    firstBtn = new JButton("First");
	    previousBtn = new JButton("Previous");
	    nextBtn = new JButton("Next");
	    lastBtn = new JButton("Last");
		
        JPanel btnPanel1 = new JPanel();
        JPanel btnPanel2 = new JPanel();
        
        btnPanel1.add(addBtn);
        btnPanel1.add(updateBtn);
        btnPanel2.add(firstBtn);
        btnPanel2.add(previousBtn);
        btnPanel2.add(nextBtn);
        btnPanel2.add(lastBtn);
		/*
		not used for btn alignment
        JPanel btnPanels = new JPanel();
        btnPanels.setLayout(new GridLayout(2,1,10,10));
        btnPanels.add(btnPanel1);
        btnPanels.add(btnPanel2);
        */
        
      //container Panel is to hold subpanels with a grid layout and 10px padding 
		JPanel container = new JPanel(new GridLayout(2,2,10,10));
		container.add(leftPanel);
        container.add(rightPanel);
        container.add(btnPanel1);
		
        //outerPanel is to add padding to the container panel and the btnPanel 2 with BorderLayout
		JPanel outerPanel = new JPanel(new BorderLayout());
		outerPanel.setBorder(BorderFactory.createEmptyBorder(30, 25, 45, 25)); // Sets top, left, bottom, and right margins
        outerPanel.add(container);
        outerPanel.add(btnPanel2, BorderLayout.SOUTH);
        
        //The JFrame only needs to add the outerPanel which holds all the guis
        add(outerPanel);
        //Method with the action listeners of each button:
        activateButtons();
        
        //Loading products from the binary file, it should be done automatically in the constructor:
       // loadProductsBinaryFile(); //-- Method to be revised!!!
	}
	
	//Method to add action listeners to the buttons
	private void activateButtons(){
		
        addBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addProduct();
            }
        });
		
        updateBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateProduct();
            }
        });

        firstBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showProduct(0);
            }
        });

        previousBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	 int prevProduct = MainGui.productsArrayList.indexOf(getCurrentProduct()) - 1;
            	 //It will loop to the last product if clicked when the first is displayed
            	 if(prevProduct < 0 ) {
            		 int lastProduct = (MainGui.productsArrayList.size() - 1);
            		 showProduct(lastProduct);
            		 return;
            	 }
                showProduct(prevProduct);
            }
        });

        nextBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	int nextProduct = MainGui.productsArrayList.indexOf(getCurrentProduct()) + 1;
	           	 //It will loop to the first product if clicked when the last is displayed
	           	 if(nextProduct >= MainGui.productsArrayList.size() ) {
	           		 int firstProduct = MainGui.productsArrayList.indexOf(MainGui.productsArrayList.get(0));
	           		 showProduct(firstProduct);
	           		 return;
	           	 }
	
	            showProduct(nextProduct);
	            }
        });

        lastBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showProduct(MainGui.productsArrayList.size() - 1); //size()-1 will retrieve the last object of the arrayList
            }
        });
		
	};
	
	
	
	//Method to add a product - serialization of string fields working fine!!
    private void addProduct() {
    	String productName;
    	String productNameFixedSize;
    	int productID;
    	String productDesc;
    	String productDescFixedSize;
    	int quantity;
    	double unitPrice;
    	
        //Reading data from text fields with a try catch block if the numbers were invalid and setting the same size for each attribute:
    	try {
    	productName = nameField.getText();
    	productNameFixedSize = (String.format("%-15s", productName));
		productID = Integer.parseInt(idField.getText());
		productDesc = descField.getText();
		productDescFixedSize = (String.format("%-30s", productDesc));
		quantity = Integer.parseInt(quantityField.getText());
		unitPrice = Double.parseDouble(unitPriceField.getText());
    	}
    	catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid input. Please fill all fields." + "\n" + "Be sure to enter valid numbers, whole numbers for ID and quantity." + "\n" +  "Enter dot separated decimals for Price if needed.");
            return; //Exit the method if it was invalid
        }
    	
    	//Validating product ID uniqueness
        while (productIDValidator(productID) == false) {
            JOptionPane.showMessageDialog(this, "A product with the same ID already exists. Please enter a unique ID.");
            return; //Exits the method if the ID is not unique
        }
        
      //Validating quantity and price
        while (quantity <= 0 || unitPrice <= 0) {
            JOptionPane.showMessageDialog(this, "Quantity and Unit Price must be greater than 0.");
            return; //Exit the method if quantity or price is negative or 0
        }
    	   	
        //Adding the product attributes as parameters to create the product object and adding it to the products list:
    	Product product = new Product(productNameFixedSize, productID, productDescFixedSize, quantity, unitPrice);
    	MainGui.productsArrayList.add(product);
    	JOptionPane.showMessageDialog(this, "Product added!");
    	
        //Clearing the text fields after each addition
    	clearFields();
    	
        //Saving the updated list to a binary file - Method to be developed!!!
    	saveProductsBinaryFile();
    }
    
    //Method to Validate product ID uniqueness, uses a for each loop to iterate through the ArrayList Ids
    private boolean productIDValidator(int productID) {
        for (Product product : MainGui.productsArrayList) {
            if (product.getProductID() == productID) {
                return false; //Product with the same ID already exists
            }
        }  
        return true; //The ID is unique
    }

    //Method to clear the Fields after a product has been added
    private void clearFields() {
        nameField.setText(""); 
        idField.setText("");   
        descField.setText("");  
        quantityField.setText("");  
        unitPriceField.setText(""); 
    }
	
    //Method to update the current product - uses the getCurrentProduct() method (just the ID is needed)
    private void updateProduct() {
    	 Product currentProduct = getCurrentProduct();

    	    if (currentProduct == null) {
    	        //If no matching product was found
    	        JOptionPane.showMessageDialog(this, "Product not found. Please enter a valid Product ID.");
    	        return;
    	    }

    	    String productName;
    	    String productDesc;
    	    int quantity;
    	    double unitPrice;

    	    //Reading updated data from text fields with a try-catch block if the numbers were invalid:
    	    try {
    	        productName = nameField.getText();
    	        productDesc = descField.getText();
    	        quantity = Integer.parseInt(quantityField.getText());
    	        unitPrice = Double.parseDouble(unitPriceField.getText());
    	    } catch (NumberFormatException e) {
    	        JOptionPane.showMessageDialog(this, "Invalid input. Please enter valid numbers, whole numbers for quantity, and dot-separated decimals for Price.");
    	        return; //Exit the method if the input is invalid
    	    }
    	
    	  //Validating quantity and price
            while (quantity <= 0 || unitPrice <= 0) {
                JOptionPane.showMessageDialog(this, "Quantity and Unit Price must be greater than 0.");
                return; //Exit the method if quantity or price is negative or 0
            }
    	    
    	    currentProduct.setProductName(productName);
    	    currentProduct.setProductDesc(productDesc);
    	    currentProduct.setQuantity(quantity);
    	    currentProduct.setUnitPrice(unitPrice);

    	    JOptionPane.showMessageDialog(this, "Product updated!");

    	    //Clearing the text fields after updating
    	    clearFields();

    	    //Saving the updated product list to the binary file
    	    saveProductsBinaryFile();
    }

    //Method to show a product at the given index, applied to first, last, prev and next btns:
    private void showProduct(int index) {
    	if (index >= 0 && index < MainGui.productsArrayList.size()) {
            Product product = MainGui.productsArrayList.get(index);
        //Displaying the product's information in the text fields:
            nameField.setText(product.getProductName());
            idField.setText(Integer.toString(product.getProductID()));
            descField.setText(product.getProductDesc());
            quantityField.setText(Integer.toString(product.getQuantity()));
            unitPriceField.setText(Double.toString(product.getUnitPrice()));
        } else {
            // Handle the case where the index is out of bounds (e.g., display an error message)!!
            JOptionPane.showMessageDialog(this, "No more products this way, try the other way.");
        }
    	
    }
	
    //Method to get the current product (based on the ID data displayed on the field)
    //This method is needed for the update method, also for next and prev btns to work , only ID is needed.
    private Product getCurrentProduct() {
        int productID;

    	try {
            productID = Integer.parseInt(idField.getText());

        } catch (NumberFormatException e) {
            //Handling the case where the data in the fields is not valid
        	JOptionPane.showMessageDialog(this, "Invalid Product ID number.");
            return null; //Ends the method
        }
         //A for each loop to go through the productsArrayList to find the matching product
            for (Product product : MainGui.productsArrayList) {
                if (product.getProductID() == productID) {
                    return product; //Found a matching product to update
                }    
        }   	
         //We should Handle the case where no product is  found
        return null;
    };
  
    //Method to save products to the binary file - to be revised!!
    private void saveProductsBinaryFile() {
        try (ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream("src/product.dat"));) {
			output.writeObject(MainGui.productsArrayList);
        } catch (IOException e) {
        	JOptionPane.showMessageDialog(this, "Error saving products into the binary file!");
        }
    }
    /*
    //Method to load products from the binary file - to be revised!!
    private void loadProductsBinaryFile() {
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream("src\\product.dat"))) {
        	//Not sure if this will work
        	MainGui.productsArrayList = (ArrayList<Product>) input.readObject();
        	JOptionPane.showMessageDialog(this, "Products loaded successfully from binary file!");
        } catch (IOException | ClassNotFoundException e) {
        	JOptionPane.showMessageDialog(this, "Error loading products from binary file: " + e.getMessage());
        }
    }
    */
}
