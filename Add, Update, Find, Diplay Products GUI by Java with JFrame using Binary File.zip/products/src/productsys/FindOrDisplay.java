package productsys;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.io.*;
import java.io.Serializable;
//class for FindOrdDiplay window
public class FindOrDisplay extends JFrame {
	//declaring variable
	private static final long serialVersionUID = 1L;
	JRadioButton priceRadioBtn;
	JTextField toField;
	JTextField fromField;
	JRadioButton keywordRadioBtn;
	JTextField keywordField;
	JRadioButton AllRadioBtn;
	JTextArea displayField;
	
	//Constructor for FindOrDisplay Object with GUIs
	public FindOrDisplay() {
		setTitle(" Find/Display Product ");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(660, 350);
		setResizable(false);
		setLocationRelativeTo(null);
		setVisible(true);
		
		//container for four panels(radiobuttons, 2 textfield, and jbutton)
		JPanel upperPanel = new JPanel();
		upperPanel.setLayout(new GridLayout(1,4));
		//panel for radio buttons
		JPanel radioButtonPanel = new JPanel();
		radioButtonPanel.setLayout(new GridLayout(3,1));
		
		//Radio Buttons need to be grouped because only one of them can be selected
		priceRadioBtn = new JRadioButton("Price Range");
		keywordRadioBtn = new JRadioButton("Keyword");
		AllRadioBtn = new JRadioButton("All");
		
		ButtonGroup radioGroup = new ButtonGroup();
		radioGroup.add(priceRadioBtn);
		radioGroup.add(keywordRadioBtn);
		radioGroup.add(AllRadioBtn);
		radioButtonPanel.add(priceRadioBtn);
		radioButtonPanel.add(keywordRadioBtn);
		radioButtonPanel.add(AllRadioBtn);
		//second panel for text field from and keyword where user will provide input
		GridLayout gridLayout = new GridLayout(3, 1);
		gridLayout.setVgap(17);
		JPanel secondPanel = new JPanel();
		secondPanel.setLayout(gridLayout);
		fromField = new JTextField("from");
		keywordField = new JTextField("keyword");
		secondPanel.add(fromField);
		secondPanel.add(keywordField);
		//third panel where to text field 
		JPanel thirdPanel = new JPanel();
		thirdPanel.setLayout(new GridLayout(4,1));
		toField = new JTextField("to");
		thirdPanel.add(toField);
		//fourth panel for the find/display button 
		JPanel fourthPanel = new JPanel();
		JButton findBtn = new JButton("Find/Display");
		fourthPanel.add(findBtn);
		
		upperPanel.add(radioButtonPanel);
		upperPanel.add(secondPanel);
		upperPanel.add(thirdPanel);
		upperPanel.add(fourthPanel);
		
		//text area where it will display the output of search 
		displayField = new JTextArea();
		displayField.setEditable(false);
		displayField.setWrapStyleWord(true);
		displayField.setLineWrap(true);
		//panel for display field text area
		JPanel lowerPanel = new JPanel();
		lowerPanel.setLayout(new GridLayout(1,1));
		lowerPanel.add(new JScrollPane(displayField));
		
		JPanel outerPanel = new JPanel(new GridLayout(2,1));
		outerPanel.setBorder(BorderFactory.createEmptyBorder(30, 25, 30, 25)); // Sets top, left, bottom, and right margins
        outerPanel.add(upperPanel);
        outerPanel.add(lowerPanel);
		
		
		add(outerPanel);
		
	
	//adding functionality to findBtn 
	findBtn.addActionListener(new ActionListener() {
        @Override
        //inner anonymous class for action event
        public void actionPerformed(ActionEvent e) {
        	//control flow to identify which radio button is selected
            //will call displayAllProducts method when allradiobutton is selected 
        	if (AllRadioBtn.isSelected()) {
                displayAllProducts();
            //will call display productsbykeyword method when keyword radiobutton is selected
            } else if (keywordRadioBtn.isSelected()) {
                displayProductsByKeyword(keywordField.getText());
            //will call displayproducttinpricerange if price radiobutton is selected
            } else if (priceRadioBtn.isSelected()) {
            	//a try-catch block to handle numberformat exception, so when user input is not in numeric format 
            	//it wont terminate the program
                try {
                    double fromPrice = Double.parseDouble(fromField.getText());
                    double toPrice = Double.parseDouble(toField.getText());
                    displayProductsInPriceRange(fromPrice, toPrice);
                } catch (NumberFormatException ex) {
                    displayField.setText("Invalid price range values.");
                }
            }
        }
    });
}
	//method to display all products in binary file when All radiobutton is selected
	private void displayAllProducts() {
		//creating a new instance of ObjectInputStream named input to read and deserialize the binary file
	    try (ObjectInputStream input = new ObjectInputStream(new FileInputStream("src/product.dat"))) {
	    	//created an instance of StringBuilder named result to concatenate the result of the search of products from 
	    	//the binary file
	        StringBuilder result = new StringBuilder("All products:\n");

	        // casting the object Product to array list. while tje readObject method will desirialized the objectt from the
	        //binary file
	        ArrayList<Product> products = (ArrayList<Product>) input.readObject();
	        //for loop that will iterate through the whole array list of products and will append the product names,
	        //product prices in the result String builder 
	        for (Product product : products) {
	            result.append("Product Name: ").append(product.getProductName()).append("Price: $").append(product.getUnitPrice()).append("\n");
	        }

	        input.close();
	        //this will set the text of displayField text area with the result
	        displayField.setText(result.toString());
	        //catch block to handle IOException(if file is not found)
	        //and ClassNotFoundException(if class definition of the object being deserialized is not found)
	    } catch (IOException | ClassNotFoundException e) {
	        displayField.setText("Error reading the binary file: " + e.getMessage());
	    }
	}


//method to display products based on users keyword input if keywordradiobtn is selected
	private void displayProductsByKeyword(String keyword) {
		//same function from 1st method
	    try (ObjectInputStream input = new ObjectInputStream(new FileInputStream("src/product.dat"))) {
	        ArrayList<Product> products = (ArrayList<Product>) input.readObject();
	        StringBuilder result = new StringBuilder("Products with keyword '" + keyword + "':\n");
	        //created a variable foundproducts to track if keyword is in the product arraylist
	        boolean foundProducts = false; 

	        //for loop that will iterate though the arraylist's productName then converting it lower case then will check
	        //if the keyword from user matches the product name 
	        //if the keyword match it will append the results of search in the result Stringbuilder
	        for (Product product : products) {
	            if (product.getProductName().toLowerCase().contains(keyword.toLowerCase())) {
	                result.append("Product Name: ").append(product.getProductName()).append("Price: $").append(product.getUnitPrice()).append("\n");
	                //sets the foundProducts variable to true if the keyword is found in the product arraylist
	                foundProducts = true;
	                
	            }
	        }
	        //if keyword from user doesnt match any productName in the ArrayList it will append this message to 
	        //result stringbuilder
	        if (!foundProducts) {
	            result.append("No products found with the keyword: " + keyword);
	        }
	        //this will set the text of displayField text area with the result
	        displayField.setText(result.toString());
	    } catch (IOException | ClassNotFoundException e) {
	        displayField.setText("Error reading the binary file: " + e.getMessage());
	    }
	}
	//method to display products in price range with parameter fromPrice(from fromField will be parsed when find/display button is clicked)
	//and toPrice(from toPrice will be parsed when find/display button is clicked)
	private void displayProductsInPriceRange(double fromPrice, double toPrice) {
		//same function from 1st method
	    try (ObjectInputStream input = new ObjectInputStream(new FileInputStream("src/product.dat"))) {
	        ArrayList<Product> products = (ArrayList<Product>) input.readObject();

	        StringBuilder result = new StringBuilder("Products in price range $" + fromPrice + " to $" + toPrice + ":\n");
	        //for loop that will iterate through the product's unitPrice in the Product ArrayList
	        for (Product product : products) {
	        	//control flow that check the check the unitPrice of products if its greaterthan or equal to user from input
	        	// and if its lessthan or equal to user's to input
	        	//if its in range the product name and price will be added to the result string builder
	            if (product.getUnitPrice() >= fromPrice && product.getUnitPrice() <= toPrice) {
	                result.append("Product Name: ").append(product.getProductName()).append("Price: $").append(product.getUnitPrice()).append("\n");
	            }
	        }
	      //this will set the text of displayField text area with the result
	        displayField.setText(result.toString());
	    } catch (IOException | ClassNotFoundException e) {
	        displayField.setText("Error reading the binary file: " + e.getMessage());
	    }
	}
	
}
