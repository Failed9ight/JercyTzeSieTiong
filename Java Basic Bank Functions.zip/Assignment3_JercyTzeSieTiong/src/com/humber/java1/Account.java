package com.humber.java1;

import java.util.Date;

public class Account {
	//private Data Fields of Account Class
	private int id;
	private double balance;
	private double annualInterestRate;
	private Date dateCreated;
	
	
	//Constructor of Account with Specified id and initial balance
	public Account() {
		this.id = 0;
		this.balance = 0.0;
		this.annualInterestRate = 0.0;
		this.dateCreated = new Date();
	}
	
	
	//No-Arg Constructor of Account
	public Account(int id, double balance) {
		this.id = id;
		this.balance = balance;
		this.annualInterestRate = 0.0;
		this.dateCreated = new Date();
	}
	
	
	//Accessor and Mutator Methods for id, balance and annualInterestRate
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public double getBalance() {
		return balance;
	}
	
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public double getAnnualInterestRate() {
		return annualInterestRate;
	}
	
	public void setAnnualInterestRate(double annualInterestRate) {
		this.annualInterestRate = annualInterestRate;
	}
	
	
	//Accessor Method for dateCreated
	public Date getDateCreated() {
		return dateCreated;
	}
	
	
	//Monthly Interest Rate Method
	public double getMonthlyInterestRate() {
		return annualInterestRate / 12;
	}
	
	
	//Monthly Interest Method
	public double getMonthlyInterest() {
		return balance * (getMonthlyInterestRate()/100);
	}
	
	
	//Withdraw Method
	public void withdraw(double withdraw) {
		balance = balance - withdraw;
	}
	
	
	//Deposit Method
	public void deposit(double deposit) {
		balance = balance + deposit;
	}
}








