﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Management.Instrumentation;
using System.Text;
using System.Threading.Tasks;

namespace n01642278_Assignment2.Product
{
    internal class Products : IEquatable<Products>
    {
		private string code;

		public string Code
		{
			get { return code; }
			set { code = value; }
		}

		private string name;

		public string Name
		{
			get { return name; }
			set { name = value; }
		}

		private double price;

		public double Price
		{
			get { return price; }
			set { price = value; }
		}

        bool IEquatable<Products>.Equals(Products other)
        {
			return this.code == other.code;
        }
    }
}
