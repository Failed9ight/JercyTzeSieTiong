﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace n01642278_Lab5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        HashSet<string> _set1 = new HashSet<string>();
        HashSet<string> _set2 = new HashSet<string>();
        HashSet<string> _set3 = new HashSet<string>();

        private void btnAddSet1_Click(object sender, EventArgs e)
        {
            if (tbAddSet1.Text.Length > 0)
            {
                _set1.Add(tbAddSet1.Text);
                tbAddSet1.Text = "";

                gvSet1.DataSource = _set1.Select(x => new { Data = x }).ToList();
                gvSet1.Refresh();
            }
            else
            {
                MessageBox.Show("Please enter data to add for Set 1");
            }
        }

        private void btnAddSet2_Click(object sender, EventArgs e)
        {
            if (tbAddSet2.Text.Length > 0)
            {
                _set2.Add(tbAddSet2.Text);
                tbAddSet2.Text = "";

                gvSet2.DataSource = _set2.Select(x => new { Data = x }).ToList();
                gvSet2.Refresh();
            }
            else
            {
                MessageBox.Show("Please enter data to add for Set 2");
            }
        }

        private void btnAddSet3_Click(object sender, EventArgs e)
        {
            if (tbAddSet3.Text.Length > 0)
            {
                _set3.Add(tbAddSet3.Text);
                tbAddSet3.Text = "";

                gvSet3.DataSource = _set3.Select(x => new { Data = x }).ToList();
                gvSet3.Refresh();
            }
            else
            {
                MessageBox.Show("Please enter data to add for Set 3");
            }
        }

        private void btnCombination_Click(object sender, EventArgs e)
        {
            HashSet<string> combinationSet = new HashSet<string>(_set1);

            combinationSet.UnionWith(_set2);
            combinationSet.UnionWith(_set3);

            gvResult.DataSource = combinationSet.Select(x => new { Data = x }).ToList();
            gvResult.Refresh();
        }

        private void btnCommon_Click(object sender, EventArgs e)
        {
            HashSet<string> commonSet = new HashSet<string>(_set1);

            commonSet.IntersectWith(_set2);
            commonSet.IntersectWith(_set3);

            gvResult.DataSource = commonSet.Select(x => new { Data = x }).ToList();
            gvResult.Refresh();
        }

        private void btnExclude_Click(object sender, EventArgs e)
        {
            HashSet<string> combinationSet = new HashSet<string>(_set1);

            combinationSet.UnionWith(_set2);
            combinationSet.UnionWith(_set3);

            HashSet<string> commonSet = new HashSet<string>(_set1);

            commonSet.IntersectWith(_set2);
            commonSet.IntersectWith(_set3);

            HashSet<string> exceptSet = new HashSet<string>(combinationSet.Except(commonSet));

            gvResult.DataSource = exceptSet.Select(x => new { Data = x }).ToList();
            gvResult.Refresh();
        }

        private void btnUniqueSet1_Click(object sender, EventArgs e)
        {
            HashSet<string> uniqueSet1 = new HashSet<string>(_set1);

            uniqueSet1.ExceptWith(_set2);
            uniqueSet1.ExceptWith(_set3);

            gvResult.DataSource = uniqueSet1.Select(x => new { Data = x }).ToList();
            gvResult.Refresh();
        }
    }
}
