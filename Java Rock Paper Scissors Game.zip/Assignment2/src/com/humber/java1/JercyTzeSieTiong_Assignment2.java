package com.humber.java1;

import java.util.Scanner;
import java.util.Random;

/**
 * 
 * @author Name: Jercy Tze Sie Tiong, Student Number N01642278
 *
 */

public class JercyTzeSieTiong_Assignment2 {

	public static void main(String[] args) {
		//Welcome Message
		System.out.println("Welcome to the unfriendly rock paper scissors game "
				+ "by Jercy Tze Sie Tiong");
		System.out.println
		("======================Rock Paper Scissors============================");
		
		
		//Prompt the user to enter his/her player name.
		Scanner player = new Scanner(System.in);
		System.out.print("Enter Player's Name: ");
		String playerName = player.nextLine();
		
		
		// Computer player named Failed9ight set, and a welcome message sent to the player.
		String computerName = "Failed9ight";
		System.out.println("Welcome " + playerName + ", you will be playing against " + computerName + " today!");
		
		
		//Initialize the count of winning round between player and computer.
		int playerWinningRounds = 0;
		int computerWinningRounds = 0;
		
		
		//Beginning of the game, keep the game going (while loop) before the user enters Q to quit the game.
		while (true) {
			String playerChoice;
			
			
			//Check if the user input is valid (matches the given options).
			while (true) {
				//Prompt message for player's choice (whether it's upper-case or lower-case, change them to upper-case).
				System.out.println("\nR ---- Rock\nP ---- Paper\nS ---- Scissors\nQ ---- Quit to calculate the result of the game.\nEnter your choice: ");
				playerChoice = player.nextLine().toUpperCase();
				
				
				if (playerChoice.equals("R") ||  playerChoice.equals("P") || playerChoice.equals("S") || playerChoice.equals("Q")) {
					break;
				}
				//By research, \u001B[31m changes text color to red, and \u001B[0m changes text color back to default.
				else {
					System.out.println("\u001B[31mInvalid choice!! Please enter your choice again!\u001B[0m");
				}
			}
				
				
			//Check if the player is quitting the game by entering "Q".
			if (playerChoice.equals("Q")) {
				break;
			}
			
				
			//Generate Random Failed9ight's (Computer) choice of rock, paper or scissors.
			Random computer = new Random();
			// Rock = 1, Paper = 2, Scissor = 3
			int randomChoice = computer.nextInt(3) + 1;
			String computerChoice;
			if (randomChoice == 1) {
				computerChoice = "R";
			}
			else if (randomChoice == 2) {
				computerChoice = "P";
			}
			else {
				computerChoice = "S";
			}
				
				
			//Display Player's Choice and Failed9ight's (Computer) Choice.
			System.out.println(playerName + "'s choice is: " + playerChoice);
			System.out.println(computerName + "'s choice is: " + computerChoice);
			
			
			//Determine the winner of each round, and count rounds win.
			String winner;
			if (playerChoice.equals(computerChoice)) {
				winner = "It's a tie!";
			}
			else if (playerChoice.equals("R") && computerChoice.equals("S") || (playerChoice.equals("P") && computerChoice.equals("R")) || (playerChoice.equals("S") && computerChoice.equals("P"))){
				winner = playerName + " Win!";
				playerWinningRounds++;
			}
			else {
				winner = computerName + " win!";
				computerWinningRounds++;
			}
			
			
			//Display Round Winner.
			System.out.println(winner);
			
			
			//Display Current Score.
			System.out.println(playerName + "'s Score: " + playerWinningRounds + "\n" + computerName + "'s Score: " + computerWinningRounds);
		}
		
		
		//Once the Q is hit and exit, calculate the final score and display it!
		if (playerWinningRounds > computerWinningRounds) {
			System.out.println(playerName + " wins! Congrats, you still have something to be proud of out of your loser life!");
		}
		else if (computerWinningRounds > playerWinningRounds) {
			System.out.println(computerName + " wins! You Loser!");
		}
		else {
			System.out.println("It's a tie! You can't even win against a computer in rock paper scissors, loser!");
		}
	}
}