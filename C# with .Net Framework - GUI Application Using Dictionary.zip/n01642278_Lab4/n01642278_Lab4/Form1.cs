﻿using n01642278_Lab4.Database;
using n01642278_Lab4.Students;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace n01642278_Lab4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        StudentDB dbObj = new StudentDB();

        private void btnAdd_Click (object sender, EventArgs e)
        {
            if (tbStudentID.Text.Length > 0 && tbName.Text.Length > 0 && tbAge.Text.Length > 0 && tbAddress.Text.Length > 0)
            {
                
                Student studentObj = GetStudent();

                bool success = dbObj.AddStudent(studentObj);

                if (success)
                {
                    MessageBox.Show("Added successfully");
                }
                else
                {
                    MessageBox.Show("Error, student id already existed");
                }
            }
            else
            {
                MessageBox.Show("Please enter all details");
            }
            gvStudent.DataSource = dbObj.GetAllStudents();
            gvStudent.Refresh();
        }

        private Student GetStudent()
        {

            Student student = new Student();
            student.StudentID = tbStudentID.Text;
            student.Name = tbName.Text;
            student.Age = int.Parse(tbAge.Text);
            student.Address = tbAddress.Text;
            return student;
        }

        private void btnFindByID_Click(object sender, EventArgs e)
        {
            String studentID = tbStudentID.Text;

            Student isFound = dbObj.FindStudentByID(studentID);

            if (isFound == null)
            {
                MessageBox.Show("StudentId doesn't exists");
            }
            else
            {
                MessageBox.Show("Student found");
                tbStudentID.Text = isFound.StudentID;
                tbName.Text = isFound.Name;
                tbAge.Text = isFound.Age.ToString();
                tbAddress.Text = isFound.Address;
            }
        }

        private void btnRemoveByID_Click(object sender, EventArgs e)
        {
            String studentID = tbStudentID.Text;

            bool success = dbObj.RemoveStudentByID(studentID);

            if (success)
            {
                MessageBox.Show("Removed successfully");
            }
            else
            {
                MessageBox.Show("Student not found");
            }

            gvStudent.DataSource = dbObj.GetAllStudents();
            gvStudent.Refresh();
        }

        private void btnDisplayIDs_Click(object sender, EventArgs e)
        {
            string[] studentIDs = dbObj.GetStudentID();
            var result = studentIDs.Select(x => new { studentID = x}).ToList();
            // After researching on the internet, I found that the only property that DataGridView displays for a string is length.
            // Therefore, with the solution I found, I encapsulate the string to a list class, so the DataGridView could display the text of string.
            gvStudent.DataSource = result;
            gvStudent.Refresh();
        }

        private void btnClearStudents_Click(object sender, EventArgs e)
        {
            dbObj.RemoveAllStudent();

            MessageBox.Show("All students are removed from the list");
            gvStudent.DataSource = dbObj.GetAllStudents();
            gvStudent.Refresh();
        }
    }
}
