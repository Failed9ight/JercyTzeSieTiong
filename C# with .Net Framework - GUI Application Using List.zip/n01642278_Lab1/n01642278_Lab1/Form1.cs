﻿using n01642278_Lab1.DAO;
using n01642278_Lab1.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace n01642278_Lab1
{

    public partial class CustomerApplication : Form
    {
        CustomerDAO customerDAO = new CustomerDAO();

        public CustomerApplication()
        {
            InitializeComponent();
        }
        private void label1_Click(object sender, EventArgs e)
        {}
        private void Form1_Load(object sender, EventArgs e)
        {}

        private void btnAddCustomer_Click(object sender, EventArgs e)
        {
            Customer customer = new Customer();
            customer.FirstName = tbFirstname.Text;
            customer.LastName = tbLastname.Text;

            bool success = customerDAO.AddNewCustomer(customer);

            if (success)
            {
                MessageBox.Show("Customer is added", "Add Customer", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Customer is failed to be added", "Add Customer", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDisplayCustomers_Click(object sender, EventArgs e)
        {
            Customer[] custArray = customerDAO.GetAllCustomer();

            if(custArray != null)
            {
                customerGridView.DataSource = custArray;
                customerGridView.Refresh();
            }
        }

        private void btnRemoveCustomer_Click(object sender, EventArgs e)
        {
            Customer oldcustomer = new Customer();
            oldcustomer.FirstName = tbFirstname.Text;
            oldcustomer.LastName = tbLastname.Text;

            bool remove = customerDAO.RemoveNewCustomer(oldcustomer);

            if (remove)
            {
                MessageBox.Show("Customer is removed", "Remove Customer", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Customer is failed to be removed", "Remove Customer", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
