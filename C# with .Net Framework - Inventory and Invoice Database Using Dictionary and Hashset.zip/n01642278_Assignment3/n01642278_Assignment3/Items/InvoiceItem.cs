﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace n01642278_Assignment3.Items
{
    internal class InvoiceItem : IEquatable<InvoiceItem>
    {
        private string itemCode;

        public string ItemCode
        {
            get { return itemCode; }
            set { itemCode = value; }
        }

        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        private double price;

        public double Price
        {
            get { return price; }
            set { price = value; }
        }

        private int quantitySold;

        public int QuantitySold
        {
            get { return quantitySold; }
            set { quantitySold = value; }
        }

        private double subTotal;

        public double SubTotal
        {
            get { return subTotal; }
            set { subTotal = value; }
        }

        bool IEquatable<InvoiceItem>.Equals(InvoiceItem other)
        {
            return this.name == other.name;
        }

        // By researching on internet, GetHashCode method needs to be overrides with the equals
        // method in order for the comparison to work for hashset. The reason is, when an object
        // is added to a hashset, the hashset of the object is already created, so even overriding
        // the equal method of the object will not override the hashcode of the object in the
        // hashset. Therefore, contraction will still appear while comparing the hashcode of the
        // object. Hence, GetHashCode method has to be overrided, too.
        public override int GetHashCode()
        {
            return Name.GetHashCode();
        }
    }
}
