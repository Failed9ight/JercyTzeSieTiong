﻿namespace n01642278_Lab3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnAddFirst = new System.Windows.Forms.Button();
            this.btnAddLast = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tbCoachID = new System.Windows.Forms.TextBox();
            this.tbLoadCapacity = new System.Windows.Forms.TextBox();
            this.tbCoachType = new System.Windows.Forms.TextBox();
            this.gvCoach = new System.Windows.Forms.DataGridView();
            this.btnRefreshData = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.tbTargetCoachID = new System.Windows.Forms.TextBox();
            this.btnAddBefore = new System.Windows.Forms.Button();
            this.btnAddAfter = new System.Windows.Forms.Button();
            this.btnRemoveBefore = new System.Windows.Forms.Button();
            this.btnRemoveAfter = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gvCoach)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 34);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "Coach ID";
            // 
            // btnAddFirst
            // 
            this.btnAddFirst.Location = new System.Drawing.Point(37, 139);
            this.btnAddFirst.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnAddFirst.Name = "btnAddFirst";
            this.btnAddFirst.Size = new System.Drawing.Size(56, 18);
            this.btnAddFirst.TabIndex = 1;
            this.btnAddFirst.Text = "Add First";
            this.btnAddFirst.UseVisualStyleBackColor = true;
            this.btnAddFirst.Click += new System.EventHandler(this.btnAddFirst_Click);
            // 
            // btnAddLast
            // 
            this.btnAddLast.Location = new System.Drawing.Point(110, 139);
            this.btnAddLast.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnAddLast.Name = "btnAddLast";
            this.btnAddLast.Size = new System.Drawing.Size(56, 18);
            this.btnAddLast.TabIndex = 2;
            this.btnAddLast.Text = "Add Last";
            this.btnAddLast.UseVisualStyleBackColor = true;
            this.btnAddLast.Click += new System.EventHandler(this.btnAddLast_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(184, 139);
            this.btnRemove.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(57, 18);
            this.btnRemove.TabIndex = 3;
            this.btnRemove.Text = "Remove";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 64);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "Load Capacity";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(35, 92);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 12);
            this.label3.TabIndex = 5;
            this.label3.Text = "Coach Type";
            // 
            // tbCoachID
            // 
            this.tbCoachID.Location = new System.Drawing.Point(110, 34);
            this.tbCoachID.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbCoachID.Name = "tbCoachID";
            this.tbCoachID.Size = new System.Drawing.Size(121, 22);
            this.tbCoachID.TabIndex = 6;
            // 
            // tbLoadCapacity
            // 
            this.tbLoadCapacity.Location = new System.Drawing.Point(110, 64);
            this.tbLoadCapacity.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbLoadCapacity.Name = "tbLoadCapacity";
            this.tbLoadCapacity.Size = new System.Drawing.Size(121, 22);
            this.tbLoadCapacity.TabIndex = 7;
            // 
            // tbCoachType
            // 
            this.tbCoachType.Location = new System.Drawing.Point(110, 92);
            this.tbCoachType.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbCoachType.Name = "tbCoachType";
            this.tbCoachType.Size = new System.Drawing.Size(121, 22);
            this.tbCoachType.TabIndex = 8;
            // 
            // gvCoach
            // 
            this.gvCoach.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvCoach.Location = new System.Drawing.Point(287, 19);
            this.gvCoach.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.gvCoach.Name = "gvCoach";
            this.gvCoach.RowHeadersWidth = 51;
            this.gvCoach.RowTemplate.Height = 27;
            this.gvCoach.Size = new System.Drawing.Size(369, 175);
            this.gvCoach.TabIndex = 9;
            // 
            // btnRefreshData
            // 
            this.btnRefreshData.Location = new System.Drawing.Point(463, 212);
            this.btnRefreshData.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnRefreshData.Name = "btnRefreshData";
            this.btnRefreshData.Size = new System.Drawing.Size(56, 18);
            this.btnRefreshData.TabIndex = 10;
            this.btnRefreshData.Text = "Refresh Data";
            this.btnRefreshData.UseVisualStyleBackColor = true;
            this.btnRefreshData.Click += new System.EventHandler(this.btnRefreshData_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(35, 242);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 12);
            this.label4.TabIndex = 11;
            this.label4.Text = "Target Coach ID";
            // 
            // tbTargetCoachID
            // 
            this.tbTargetCoachID.AcceptsTab = true;
            this.tbTargetCoachID.Location = new System.Drawing.Point(121, 239);
            this.tbTargetCoachID.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbTargetCoachID.Name = "tbTargetCoachID";
            this.tbTargetCoachID.Size = new System.Drawing.Size(120, 22);
            this.tbTargetCoachID.TabIndex = 12;
            // 
            // btnAddBefore
            // 
            this.btnAddBefore.Location = new System.Drawing.Point(30, 278);
            this.btnAddBefore.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnAddBefore.Name = "btnAddBefore";
            this.btnAddBefore.Size = new System.Drawing.Size(88, 18);
            this.btnAddBefore.TabIndex = 13;
            this.btnAddBefore.Text = "Add Before";
            this.btnAddBefore.UseVisualStyleBackColor = true;
            this.btnAddBefore.Click += new System.EventHandler(this.btnAddBefore_Click);
            // 
            // btnAddAfter
            // 
            this.btnAddAfter.Location = new System.Drawing.Point(132, 278);
            this.btnAddAfter.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnAddAfter.Name = "btnAddAfter";
            this.btnAddAfter.Size = new System.Drawing.Size(99, 18);
            this.btnAddAfter.TabIndex = 14;
            this.btnAddAfter.Text = "Add After";
            this.btnAddAfter.UseVisualStyleBackColor = true;
            this.btnAddAfter.Click += new System.EventHandler(this.btnAddAfter_Click);
            // 
            // btnRemoveBefore
            // 
            this.btnRemoveBefore.Location = new System.Drawing.Point(30, 313);
            this.btnRemoveBefore.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnRemoveBefore.Name = "btnRemoveBefore";
            this.btnRemoveBefore.Size = new System.Drawing.Size(88, 18);
            this.btnRemoveBefore.TabIndex = 15;
            this.btnRemoveBefore.Text = "Remove Before";
            this.btnRemoveBefore.UseVisualStyleBackColor = true;
            this.btnRemoveBefore.Click += new System.EventHandler(this.btnRemoveBefore_Click);
            // 
            // btnRemoveAfter
            // 
            this.btnRemoveAfter.Location = new System.Drawing.Point(132, 313);
            this.btnRemoveAfter.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnRemoveAfter.Name = "btnRemoveAfter";
            this.btnRemoveAfter.Size = new System.Drawing.Size(99, 18);
            this.btnRemoveAfter.TabIndex = 16;
            this.btnRemoveAfter.Text = "Remove After";
            this.btnRemoveAfter.UseVisualStyleBackColor = true;
            this.btnRemoveAfter.Click += new System.EventHandler(this.btnRemoveAfter_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(667, 360);
            this.Controls.Add(this.btnRemoveAfter);
            this.Controls.Add(this.btnRemoveBefore);
            this.Controls.Add(this.btnAddAfter);
            this.Controls.Add(this.btnAddBefore);
            this.Controls.Add(this.tbTargetCoachID);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnRefreshData);
            this.Controls.Add(this.gvCoach);
            this.Controls.Add(this.tbCoachType);
            this.Controls.Add(this.tbLoadCapacity);
            this.Controls.Add(this.tbCoachID);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.btnAddLast);
            this.Controls.Add(this.btnAddFirst);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.gvCoach)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAddFirst;
        private System.Windows.Forms.Button btnAddLast;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbCoachID;
        private System.Windows.Forms.TextBox tbLoadCapacity;
        private System.Windows.Forms.TextBox tbCoachType;
        private System.Windows.Forms.DataGridView gvCoach;
        private System.Windows.Forms.Button btnRefreshData;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbTargetCoachID;
        private System.Windows.Forms.Button btnAddBefore;
        private System.Windows.Forms.Button btnAddAfter;
        private System.Windows.Forms.Button btnRemoveBefore;
        private System.Windows.Forms.Button btnRemoveAfter;
    }
}

