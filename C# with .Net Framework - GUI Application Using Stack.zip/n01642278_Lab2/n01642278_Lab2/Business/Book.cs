﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace n01642278_Lab2.Business
{
    internal class Book: IEquatable<Book>
    {
		private string isbn; //propfull

		public string ISBN
		{
			get { return isbn; }
			set { isbn = value; }
		}

		private string name;

		public string Name
		{
			get { return name; }
			set { name = value; }
		}

		private string author;

		public string Author
		{
			get { return author; }
			set { author = value; }
		}

		private int numberOfPages;

		public int NumberofPages
		{
			get { return numberOfPages; }
			set { numberOfPages = value; }
		}

        bool IEquatable<Book>.Equals(Book other)
        {
			return (ISBN == other.ISBN);
        }
    }
}
