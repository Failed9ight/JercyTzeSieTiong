﻿using n01642278_Assignment2.Product;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Diagnostics.Eventing.Reader;
using System.Drawing.Printing;
using System.Linq;
using System.Runtime.Serialization;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace n01642278_Assignment2.Database
{
    internal class ProductDB
    {
        LinkedList<Products> productDB = new LinkedList<Products>();

        internal Products[] GetAllData()
        {
            return productDB.ToArray<Products>();
        }

        internal string GetAverageProductPrice()
        {
            LinkedListNode<Products> firstNode = productDB.First;

            double totalPrice = 0;

            double averagePrice = 0;

            while (firstNode != null)
            {
                totalPrice = totalPrice + firstNode.Value.Price;
                firstNode = firstNode.Next;
            }
            if (productDB.Count != 0)
            {
                averagePrice = totalPrice / productDB.Count;
                return averagePrice.ToString();
            }
            else
            {
                return averagePrice.ToString();
            }
        }

        internal string NumberOfItems()
        {
            return productDB.Count.ToString();
        }

        internal bool InsertProduct(Products productObj)
        {
            LinkedListNode<Products> targetNode = productDB.Find(productObj);
            LinkedListNode<Products> firstNode = productDB.First;

            if (firstNode == null)
            {
                productDB.AddFirst(productObj);
                return true;
            }
            else if (targetNode == null && firstNode != null)
            {
                while (firstNode != null)
                {
                    if (firstNode.Value.Price >= productObj.Price)
                    {
                        targetNode = firstNode;
                        firstNode = firstNode.Next;
                    }
                    else
                    {
                        productDB.AddBefore(firstNode, productObj);
                        return true;
                    }

                }
                productDB.AddLast(productObj);
                return true;
            }
            else
            {
                return false;
            }
        }

        internal bool RemoveByName(string name)
        {
            LinkedListNode<Products> firstNode = productDB.First;

            while (firstNode != null)
            {
                if (firstNode.Value.Name != name)
                {
                    firstNode = firstNode.Next;
                }
                else if (firstNode.Value.Name == name)
                {
                    productDB.Remove(firstNode.Value);
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }
    }
}
