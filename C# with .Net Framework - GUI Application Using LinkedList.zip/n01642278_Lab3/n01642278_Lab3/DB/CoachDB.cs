﻿using n01642278_Lab3.Business;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace n01642278_Lab3.DB
{
    internal class CoachDB
    {
        LinkedList<TrainCoach> coaches = new LinkedList<TrainCoach>();

        internal bool AddCoachAtFirst(TrainCoach newCoach)
        {
            if (coaches.Contains(newCoach) != true)
            {

                coaches.AddFirst(newCoach);

                return true;
            }
            else
            {
                return false;
            }
        }

        internal bool AddCoachAtLast(TrainCoach newCoach)
        {
            if (coaches.Contains(newCoach) != true)
            {

                coaches.AddLast(newCoach);

                return true;
            }
            else
            {
                return false;
            }
        }

        internal bool AddNodeAfter(int targetCoachID, TrainCoach newCoach)
        {
            TrainCoach targetObj = new TrainCoach();
            targetObj.CoachID = targetCoachID;

            LinkedListNode<TrainCoach> targetNode = coaches.Find(targetObj);

            if (targetNode != null && coaches.Contains(newCoach) != true)
            {
                coaches.AddAfter(targetNode, newCoach);
                return true;
            }
            else
            {
                return false;
            }
        }

        internal bool AddNodeBefore(int targetCoachID, TrainCoach newCoach)
        {
            TrainCoach targetObj = new TrainCoach();
            targetObj.CoachID = targetCoachID;

            LinkedListNode<TrainCoach> targetNode = coaches.Find(targetObj);

            if (targetNode != null && coaches.Contains(newCoach) != true)
            {
                coaches.AddBefore(targetNode, newCoach);
                return true;
            }
            else
            {
                return false;
            }

        }

        internal TrainCoach[] GetAllData()
        {
            return coaches.ToArray<TrainCoach>();
        }

        internal bool RemoveCoach(TrainCoach existedCoach)
        {
            if (coaches.Contains(existedCoach) == true)
            {

                coaches.Remove(existedCoach);

                return true;
            }
            else
            {
                return false;
            }
        }

        internal bool RemoveNodeAfter(int targetCoachID)
        {
            TrainCoach targetObj = new TrainCoach();
            targetObj.CoachID = targetCoachID;

            LinkedListNode<TrainCoach> targetNode = coaches.Find(targetObj);

            if (targetNode != null && targetNode.Next != null)
            {
                coaches.Remove(targetNode.Next);

                return true;
            }
            else
            {
                return false;
            }
        }

        internal bool RemoveNodeBefore(int targetCoachID)
        {
            TrainCoach targetObj = new TrainCoach();
            targetObj.CoachID = targetCoachID;

            LinkedListNode<TrainCoach> targetNode = coaches.Find(targetObj);

            if (targetNode != null && targetNode.Previous != null)
            {
                coaches.Remove(targetNode.Previous);

                return true;
            }
            else
            {
                return false;
            }

        }
    }


}
