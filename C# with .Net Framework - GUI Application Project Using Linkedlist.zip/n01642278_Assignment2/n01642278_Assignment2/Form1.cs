﻿using n01642278_Assignment2.Database;
using n01642278_Assignment2.Product;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace n01642278_Assignment2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        ProductDB productDB = new ProductDB();

        private void btnInsert_Click(object sender, EventArgs e)
        {
            Products productObj = GetProduct();
            
            if (productObj == null)
            {
                MessageBox.Show("Please enter required product details");
            }
            else
            {
                bool success = productDB.InsertProduct(productObj);

                if (success)
                {
                    MessageBox.Show("Product inserted added successfully");
                }
                else
                {
                    MessageBox.Show("Product Code already existed");
                }
            }


            tbNumberOfProducts.Text = productDB.NumberOfItems();
            tbAveragePrice.Text = productDB.GetAverageProductPrice();

            gvProduct.DataSource = productDB.GetAllData();
            gvProduct.Refresh();
        }

        private Products GetProduct()
        {
            if (tbProductCode.Text.Length > 0 && tbProductName.Text.Length > 0 && tbProductPrice.Text.Length > 0)
            {
                Products p = new Products();
                p.Code = tbProductCode.Text;
                p.Name = tbProductName.Text;
                p.Price = double.Parse(tbProductPrice.Text);
                return p;
            }
            else
            {
                return null;
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (tbProductName.Text.Length > 0)
            {
                Products targetProduct = new Products();
                targetProduct.Name = tbProductName.Text;

                bool success = productDB.RemoveByName(targetProduct.Name);

                if (success)
                {
                    MessageBox.Show("Product removed by name successfully");
                }
                else
                {
                    MessageBox.Show("Product name is not in the database");
                }
            }
            else
            {
                MessageBox.Show("Please enter the product name");
            }

            tbNumberOfProducts.Text = productDB.NumberOfItems();
            tbAveragePrice.Text = productDB.GetAverageProductPrice();

            gvProduct.DataSource = productDB.GetAllData();
            gvProduct.Refresh();
        }
    }
}
