﻿using n01642278_Lab1.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace n01642278_Lab1.DAO
{
    internal class CustomerDAO
    {
        List<Customer> customersList = new List<Customer>();

        internal bool AddNewCustomer(Customer customer){
            if (customersList.Contains(customer))
            {
                return false;
            }
            else
            {
                customersList.Add(customer);
                return true;
            }
        }

        internal Customer[] GetAllCustomer()
        {
            return customersList.ToArray();
        }

        internal bool RemoveNewCustomer(Customer customer)
        {
            if (customersList.Contains(customer))
            {
                customersList.Remove(customer);
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
